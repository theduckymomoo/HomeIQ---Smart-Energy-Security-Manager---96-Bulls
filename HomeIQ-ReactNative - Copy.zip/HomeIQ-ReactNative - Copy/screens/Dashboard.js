import React, { useState, useEffect } from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Dimensions, Image } from 'react-native';
import { useSafeAreaInsets, SafeAreaProvider } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { useAuth } from '../Context/AuthContext';

import AnalysisTab from './DashboardComponets/AnalysisTab';
import ControlsTab from './DashboardComponets/ControlsTab';
import HomeTab from './DashboardComponets/HomeTab';
import SecurityTab from './DashboardComponets/SecurityTab';
import SettingsTab from './DashboardComponets/SettingsTab';

const { width } = Dimensions.get('window');

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [appliances, setAppliances] = useState([]);
  const [stats, setStats] = useState({
    totalUsage: 0,
    monthlyCost: 0,
    activeDevices: 0,
    efficiency: 85,
  });
  const insets = useSafeAreaInsets();
  const { user, supabase } = useAuth();

  const tabs = [
    { name: 'Home', component: HomeTab, icon: 'home' },
    { name: 'Analytics', component: AnalysisTab, icon: 'bar-chart' },
    { name: 'Controls', component: ControlsTab, icon: 'tune' },
    { name: 'Security', component: SecurityTab, icon: 'shield' },
    { name: 'Settings', component: SettingsTab, icon: 'settings' },
  ];

  // Fetch appliances data
  const fetchAppliances = async () => {
    if (!user?.id) return;

    try {
      const { data, error } = await supabase
        .from('appliances')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching appliances:', error);
        return;
      }

      setAppliances(data || []);
      calculateStats(data || []);
    } catch (error) {
      console.error('Error in fetchAppliances:', error);
    }
  };

  const calculateStats = (applianceList) => {
    const activeAppliances = applianceList.filter(app => app.status === 'on');
    const totalUsage = activeAppliances.reduce((sum, app) => sum + app.normal_usage, 0);

    const kWh = totalUsage / 1000;
    const hoursPerMonth = 24 * 30;
    const monthlyCost = kWh * hoursPerMonth * 2.50;

    const avgUsagePerDevice = totalUsage / Math.max(activeAppliances.length, 1);
    let efficiency = 100;
    if (avgUsagePerDevice > 300) efficiency = 60;
    else if (avgUsagePerDevice > 200) efficiency = 70;
    else if (avgUsagePerDevice > 100) efficiency = 80;
    else efficiency = 90;

    setStats({
      totalUsage: Math.round(totalUsage),
      monthlyCost: Math.round(monthlyCost),
      activeDevices: activeAppliances.length,
      efficiency,
    });
  };

  useEffect(() => {
    if (user?.id) {
      fetchAppliances();
    }
  }, [user?.id]);

  const renderActiveComponent = () => {
    const ActiveComponent = tabs[activeTab].component;
    
    if (activeTab === 1) {
      return <AnalysisTab appliances={appliances} stats={stats} />;
    }
    
    return <ActiveComponent />;
  };

  const handleUserSettings = () => {
    console.log('User settings pressed');
  };

  return (
    <View style={[
      styles.container,
      { paddingTop: insets.top, paddingBottom: insets.bottom }
    ]}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.logoContainer}>
          <Image 
            source={require('../assets/logo.png')}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>
        
        <TouchableOpacity 
          style={styles.userIconContainer}
          onPress={handleUserSettings}
          activeOpacity={0.7}
        >
          <View style={styles.userIcon}>
            <Text style={styles.userIconText}>👤</Text>
          </View>
        </TouchableOpacity>
      </View>

      {/* Main Content */}
      <View style={styles.content}>
        {renderActiveComponent()}
      </View>

      {/* Bottom Navigation */}
      <View style={styles.bottomNavigation}>
        {tabs.map((tab, index) => (
          <TouchableOpacity
            key={index}
            style={styles.navButton}
            onPress={() => setActiveTab(index)}
            activeOpacity={0.7}
          >
            <MaterialIcons 
              name={tab.icon} 
              size={24} 
              color={activeTab === index ? '#10b981' : '#6c757d'} 
            />
            <Text style={[
              styles.navText,
              activeTab === index && styles.activeNavText
            ]}>
              {tab.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0b',
  },
  header: {
    backgroundColor: '#0a0a0b',
    paddingHorizontal: 24,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    height: 60,
  },
  logoContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 50,
    height: 50,
  },
  userIconContainer: {
    padding: 6,
  },
  userIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  userIconText: {
    fontSize: 18,
  },
  content: {
    flex: 1,
    backgroundColor: '#0a0a0b',
  },
  bottomNavigation: {
    flexDirection: 'row',
    backgroundColor: '#0a0a0b',
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderTopWidth: 1,
    borderTopColor: '#18181b',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  navButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
  },
  navText: {
    fontSize: width < 375 ? 10 : 11,
    color: '#6c757d',
    textAlign: 'center',
    fontWeight: '500',
    marginTop: 4,
  },
  activeNavText: {
    color: '#10b981',
    fontWeight: '600',
  },
});

const App = () => {
  return (
    <SafeAreaProvider>
      <Dashboard />
    </SafeAreaProvider>
  );
};

export default Dashboard;