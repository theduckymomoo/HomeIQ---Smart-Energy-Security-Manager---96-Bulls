// SettingsTab.js - Updated version with proper theme switching
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Switch,
  Alert,
  TextInput,
  Modal,
  Dimensions,
  StatusBar,
  Vibration,
  Share,
  Linking,
  StyleSheet,
  Platform,
  useColorScheme,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';
import { useAuth } from '../../Context/AuthContext';

const { width } = Dimensions.get('window');

// ===== Config =====
const APP_NAME = 'HomeIQ';
const SUPPORT_EMAIL = 'support@homeiq.app';
const PRIVACY_URL = 'https://example.com/privacy';
const TERMS_URL = 'https://example.com/terms';
const HELP_URL = 'https://example.com/help';
const APP_STORE_ID = '';
const PLAY_STORE_PACKAGE_NAME = '';
// ==================

// ---------- Theme Colors ----------
const lightTheme = {
  background: '#ffffff',
  surface: '#f8f9fa',
  text: '#000000',
  textSecondary: '#6b7280',
  border: 'rgba(0,0,0,0.1)',
  card: '#ffffff',
  cardBorder: 'rgba(0,0,0,0.1)',
  inputBackground: 'rgba(0,0,0,0.05)',
  inputBorder: 'rgba(0,0,0,0.2)',
  button: '#10b981',
  buttonText: '#ffffff',
  ghostButtonBorder: 'rgba(0,0,0,0.2)',
  ghostButtonText: '#374151',
  danger: '#ef4444',
  overlay: 'rgba(0,0,0,0.5)',
};

const darkTheme = {
  background: '#0b0b0c',
  surface: '#111214',
  text: '#ffffff',
  textSecondary: '#9ca3af',
  border: 'rgba(255,255,255,0.07)',
  card: '#111214',
  cardBorder: 'rgba(255,255,255,0.08)',
  inputBackground: 'rgba(255,255,255,0.05)',
  inputBorder: 'rgba(255,255,255,0.16)',
  button: '#10b981',
  buttonText: '#0b0b0c',
  ghostButtonBorder: 'rgba(255,255,255,0.18)',
  ghostButtonText: '#e5e7eb',
  danger: '#ef4444',
  overlay: 'rgba(0,0,0,0.56)',
};

// ---------- Helpers ----------
const star = (filled) => (
  <MaterialIcons name={filled ? 'star' : 'star-border'} size={28} color="#f59e0b" />
);

const openStoreReviewPage = async () => {
  const iosUrl = APP_STORE_ID ? `itms-apps://itunes.apple.com/app/id${APP_STORE_ID}?action=write-review` : null;
  const androidMarket = PLAY_STORE_PACKAGE_NAME ? `market://details?id=${PLAY_STORE_PACKAGE_NAME}` : null;
  const androidWeb = PLAY_STORE_PACKAGE_NAME ? `https://play.google.com/store/apps/details?id=${PLAY_STORE_PACKAGE_NAME}` : null;
  const fallback = `https://www.google.com/search?q=${encodeURIComponent(APP_NAME + ' app')}`;

  const target = Platform.OS === 'ios' ? (iosUrl ?? fallback) : (androidMarket ?? androidWeb ?? fallback);
  try {
    await Linking.openURL(target);
  } catch {
    await Linking.openURL(fallback);
  }
};

const mailto = (to, subject, body) =>
  Linking.openURL(
    `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  );

// ---------- UI atoms ----------
const SectionHeader = ({ title, theme }) => (
  <Text style={[styles(theme).sectionHeader]}>{title}</Text>
);

const Row = ({ icon, title, subtitle, right, onPress, danger, border = true, theme }) => (
  <TouchableOpacity
    onPress={onPress}
    disabled={!onPress}
    style={[
      styles(theme).row,
      border && styles(theme).rowBorder,
      danger && { borderColor: 'rgba(239,68,68,0.35)' },
    ]}
  >
    <View style={styles(theme).rowLeft}>
      <Text style={styles(theme).rowIcon}>{icon}</Text>
      <View style={{ flex: 1 }}>
        <Text style={[styles(theme).rowTitle, danger && { color: theme.danger }]}>{title}</Text>
        {subtitle ? <Text style={styles(theme).rowSubtitle}>{subtitle}</Text> : null}
      </View>
    </View>
    <View style={styles(theme).rowRight}>{right ?? <Text style={styles(theme).disclosure}>›</Text>}</View>
  </TouchableOpacity>
);

// ========== Main ==========
const SettingsTab = () => {
  const { user, userProfile, supabase, updateProfile, signOut, getUserSettings, upsertUserSettings } = useAuth();
  const systemColorScheme = useColorScheme();

  // ------- UI state -------
  const [profileModalVisible, setProfileModalVisible] = useState(false);
  const [pwdModalVisible, setPwdModalVisible] = useState(false);
  const [emailPrefsVisible, setEmailPrefsVisible] = useState(false);
  const [energyModalVisible, setEnergyModalVisible] = useState(false);
  const [aboutVisible, setAboutVisible] = useState(false);
  const [rateVisible, setRateVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loadingSettings, setLoadingSettings] = useState(true);

  // Profile edits
  const [editProfile, setEditProfile] = useState({
    firstName: '',
    lastName: '',
    phone: '',
  });

  // Settings (persisted)
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [haptics, setHaptics] = useState(true);
  const [energyAlerts, setEnergyAlerts] = useState(true);
  const [energyThreshold, setEnergyThreshold] = useState('300');
  const [autoOptimize, setAutoOptimize] = useState(false);
  const [weeklyReports, setWeeklyReports] = useState(true);
  const [currency, setCurrency] = useState('ZAR');
  const [language, setLanguage] = useState('English');
  const [emailMarketing, setEmailMarketing] = useState(true);
  const [emailProduct, setEmailProduct] = useState(true);

  const version = useMemo(() => Constants.expoConfig?.version ?? '1.0.0', []);
  
  // Current theme based on darkMode state
  const theme = darkMode ? darkTheme : lightTheme;

  // Haptic helper
  const tick = () => {
    if (haptics) Vibration.vibrate(50);
  };

  // ---------- Load user + settings ----------
  const hydrateProfile = useCallback(() => {
    if (!userProfile) return;
    setEditProfile({
      firstName: userProfile.first_name || '',
      lastName: userProfile.last_name || '',
      phone: userProfile.phone || '',
    });
  }, [userProfile]);

  const loadUserSettings = useCallback(async () => {
    if (!user?.id) return;
    
    try {
      setLoadingSettings(true);
      const settings = await getUserSettings();
      
      if (settings) {
        setDarkMode(!!settings.dark_mode);
        setNotifications(!!settings.notifications);
        setHaptics(!!settings.haptic_feedback);
        setEnergyAlerts(!!settings.energy_alerts);
        setEnergyThreshold(String(settings.energy_threshold ?? '300'));
        setAutoOptimize(!!settings.auto_optimization);
        setWeeklyReports(!!settings.weekly_reports);
        setCurrency(settings.currency ?? 'ZAR');
        setLanguage(settings.language ?? 'English');
        setEmailMarketing(!!settings.email_marketing);
        setEmailProduct(!!settings.email_product);
      }
    } catch (e) {
      console.warn('loadUserSettings error:', e.message);
      // Fallback to AsyncStorage if database fails
      try {
        const cached = await AsyncStorage.getItem('@settings');
        if (cached) {
          const s = JSON.parse(cached);
          setDarkMode(!!s.darkMode);
          setNotifications(!!s.notifications);
          setHaptics(!!s.haptics);
          setEnergyAlerts(!!s.energyAlerts);
          setEnergyThreshold(String(s.energyThreshold ?? '300'));
          setAutoOptimize(!!s.autoOptimize);
          setWeeklyReports(!!s.weeklyReports);
          setCurrency(s.currency ?? 'ZAR');
          setLanguage(s.language ?? 'English');
          setEmailMarketing(!!s.emailMarketing);
          setEmailProduct(!!s.emailProduct);
        }
      } catch (cacheError) {
        console.warn('Cache fallback failed:', cacheError.message);
      }
    } finally {
      setLoadingSettings(false);
    }
  }, [user?.id, getUserSettings]);

  useEffect(() => {
    hydrateProfile();
  }, [hydrateProfile]);

  useEffect(() => {
    loadUserSettings();
  }, [loadUserSettings]);

  // Cache to AsyncStorage on any change (as backup)
  useEffect(() => {
    const s = {
      darkMode, notifications, haptics,
      energyAlerts, energyThreshold, autoOptimize, weeklyReports,
      currency, language, emailMarketing, emailProduct,
    };
    AsyncStorage.setItem('@settings', JSON.stringify(s)).catch(() => {});
  }, [darkMode, notifications, haptics, energyAlerts, energyThreshold, autoOptimize, weeklyReports, currency, language, emailMarketing, emailProduct]);

  // ---------- Persistence ----------
  const saveSetting = useCallback(
    async (patch) => {
      if (!user?.id) return;
      
      try {
        await upsertUserSettings(patch);
        
        // Update local state to match what was saved
        if (patch.dark_mode !== undefined) setDarkMode(patch.dark_mode);
        if (patch.notifications !== undefined) setNotifications(patch.notifications);
        if (patch.haptic_feedback !== undefined) setHaptics(patch.haptic_feedback);
        if (patch.energy_alerts !== undefined) setEnergyAlerts(patch.energy_alerts);
        if (patch.energy_threshold !== undefined) setEnergyThreshold(String(patch.energy_threshold));
        if (patch.auto_optimization !== undefined) setAutoOptimize(patch.auto_optimization);
        if (patch.weekly_reports !== undefined) setWeeklyReports(patch.weekly_reports);
        if (patch.currency !== undefined) setCurrency(patch.currency);
        if (patch.language !== undefined) setLanguage(patch.language);
        if (patch.email_marketing !== undefined) setEmailMarketing(patch.email_marketing);
        if (patch.email_product !== undefined) setEmailProduct(patch.email_product);
      } catch (e) {
        Alert.alert('Save failed', e.message || 'Could not save setting.');
      }
    },
    [user?.id, upsertUserSettings]
  );

  // Handle dark mode toggle
  const handleDarkModeToggle = (value) => {
    tick();
    setDarkMode(value);
    saveSetting({ dark_mode: value });
  };

  // ---------- Actions ----------
  const handleSaveProfile = async () => {
    if (saving) return;
    const errs = [];
    if (!editProfile.firstName.trim()) errs.push('First name is required.');
    if (!editProfile.lastName.trim()) errs.push('Last name is required.');
    if (editProfile.phone && !/^[0-9+\-() ]{6,}$/.test(editProfile.phone.trim())) errs.push('Phone looks invalid.');
    if (errs.length) return Alert.alert('Please fix', errs.join('\n'));

    setSaving(true);
    try {
      const { error } = await updateProfile({
        first_name: editProfile.firstName.trim(),
        last_name: editProfile.lastName.trim(),
        phone: editProfile.phone.trim(),
      });
      if (error) throw error;
      setProfileModalVisible(false);
      Alert.alert('Success', 'Profile updated.');
    } catch (e) {
      Alert.alert('Error', e.message || 'Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (current, next, confirm) => {
    if (!next || next.length < 8) return Alert.alert('Invalid', 'New password must be at least 8 characters.');
    if (next !== confirm) return Alert.alert('Invalid', 'Passwords do not match.');

    try {
      const { data, error } = await supabase.auth.updateUser({ password: next });
      if (error) throw error;
      setPwdModalVisible(false);
      Alert.alert('Password changed', 'Use your new password next sign-in.');
    } catch (e) {
      Alert.alert('Error', e.message || 'Could not change password.');
    }
  };

  const handleExportData = useCallback(async () => {
    try {
      const rows = [];
      // profiles
      if (user?.id) {
        const { data: p } = await supabase.from('profiles').select('first_name,last_name,phone').eq('id', user.id).maybeSingle();
        if (p) rows.push(['First Name', 'Last Name', 'Phone'], [p.first_name ?? '', p.last_name ?? '', p.phone ?? ''], ['','','']);
      }
      // appliances
      const { data: appliances } = await supabase.from('appliances').select('*').eq('user_id', user?.id);
      if (appliances?.length) {
        rows.push(['Name', 'Type', 'Room', 'Usage', 'Status']);
        appliances.forEach(a => rows.push([a.name, a.type, a.room, a.usage ?? '', a.status ?? '']));
      }
      // energy usage (optional)
      try {
        const { data: usage } = await supabase.from('energy_usage').select('*').eq('user_id', user?.id);
        if (usage?.length) {
          rows.push(['','',''], ['Date', 'kWh', 'Cost']);
          usage.forEach(u => rows.push([u.date ?? '', u.kwh ?? '', u.cost ?? '']));
        }
      } catch {}

      const csv = rows.map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
      await Share.share({ title: `${APP_NAME} Export`, message: csv });
    } catch (e) {
      Alert.alert('Error', 'Failed to export data.');
    }
  }, [user?.id, supabase]);

  const handleBackup = useCallback(async () => {
    try {
      const snapshot = {
        at: new Date().toISOString(),
        profile: editProfile,
        settings: {
          darkMode, notifications, haptics, energyAlerts, energyThreshold, autoOptimize, weeklyReports, currency, language, emailMarketing, emailProduct,
        },
      };
      await Share.share({ title: `${APP_NAME} Backup`, message: JSON.stringify(snapshot, null, 2) });
    } catch {
      Alert.alert('Error', 'Failed to create backup.');
    }
  }, [editProfile, darkMode, notifications, haptics, energyAlerts, energyThreshold, autoOptimize, weeklyReports, currency, language, emailMarketing, emailProduct]);

  const handleDeleteAccount = useCallback(() => {
    Alert.alert(
      'Delete Account',
      'This removes your profile and settings. You will be signed out.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              if (!user?.id) return;
              await supabase.from('appliances').delete().eq('user_id', user.id);
              await supabase.from('energy_usage').delete().eq('user_id', user.id);
              await supabase.from('user_settings').delete().eq('id', user.id);
              await supabase.from('profiles').delete().eq('id', user.id);
              await signOut();
            } catch (e) {
              Alert.alert('Error', e.message || 'Failed to delete account data.');
            }
          },
        },
      ],
      { cancelable: true }
    );
  }, [user?.id, supabase, signOut]);

  const handleRateSubmit = async (rating, feedback) => {
    if (rating >= 4) {
      await openStoreReviewPage();
    } else {
      await mailto(
        SUPPORT_EMAIL,
        `${APP_NAME} Feedback (${rating}★)`,
        `${feedback || ''}\n\nDevice: ${Platform.OS} ${Platform.Version}`
      );
    }
    setRateVisible(false);
  };

  // Show loading state
  if (loadingSettings) {
    return (
      <View style={[styles(theme).container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: theme.text }}>Loading settings...</Text>
      </View>
    );
  }

  // ---------- Render ----------
  return (
    <>
      <StatusBar barStyle={darkMode ? 'light-content' : 'dark-content'} />
      <ScrollView style={styles(theme).container} contentContainerStyle={{ paddingBottom: 28 }}>
        {/* Account */}
        <SectionHeader title="Account" theme={theme} />
        <Row
          icon="👤"
          title="Edit Profile"
          subtitle={`${userProfile?.first_name ?? ''} ${userProfile?.last_name ?? ''}`}
          onPress={() => setProfileModalVisible(true)}
          theme={theme}
        />
        <Row
          icon="🔐"
          title="Change Password"
          subtitle="Update your account password"
          onPress={() => setPwdModalVisible(true)}
          border={false}
          theme={theme}
        />

        {/* Email Preferences */}
        <SectionHeader title="Email Preferences" theme={theme} />
        <Row
          icon="📧"
          title="Manage email subscriptions"
          subtitle="Marketing & product updates"
          onPress={() => setEmailPrefsVisible(true)}
          border={false}
          theme={theme}
        />

        {/* App Preferences */}
        <SectionHeader title="App Preferences" theme={theme} />
        <Row
          icon="🌗"
          title="Dark Mode"
          subtitle={darkMode ? 'On' : 'Off'}
          right={
            <Switch
              value={darkMode}
              onValueChange={handleDarkModeToggle}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={darkMode ? '#f5dd4b' : '#f4f3f4'}
            />
          }
          theme={theme}
        />
        <Row
          icon="🔔"
          title="Notifications"
          subtitle={notifications ? 'Enabled' : 'Disabled'}
          right={
            <Switch
              value={notifications}
              onValueChange={(v) => { tick(); setNotifications(v); saveSetting({ notifications: v }); }}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={darkMode ? '#f5dd4b' : '#f4f3f4'}
            />
          }
          theme={theme}
        />
        <Row
          icon="📳"
          title="Haptic Feedback"
          subtitle={haptics ? 'On' : 'Off'}
          right={
            <Switch
              value={haptics}
              onValueChange={(v) => { setHaptics(v); saveSetting({ haptic_feedback: v }); }}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={darkMode ? '#f5dd4b' : '#f4f3f4'}
            />
          }
          border={false}
          theme={theme}
        />

        {/* Energy */}
        <SectionHeader title="Energy Management" theme={theme} />
        <Row
          icon="⚡"
          title="Energy Alerts"
          subtitle={energyAlerts ? 'Enabled' : 'Disabled'}
          right={
            <Switch
              value={energyAlerts}
              onValueChange={(v) => { tick(); setEnergyAlerts(v); saveSetting({ energy_alerts: v }); }}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={darkMode ? '#f5dd4b' : '#f4f3f4'}
            />
          }
          theme={theme}
        />
        <Row
          icon="📈"
          title="Energy Threshold"
          subtitle={`${energyThreshold} kWh`}
          onPress={() => setEnergyModalVisible(true)}
          theme={theme}
        />
        <Row
          icon="🤖"
          title="Auto-Optimization"
          subtitle={autoOptimize ? 'On' : 'Off'}
          right={
            <Switch
              value={autoOptimize}
              onValueChange={(v) => { tick(); setAutoOptimize(v); saveSetting({ auto_optimization: v }); }}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={darkMode ? '#f5dd4b' : '#f4f3f4'}
            />
          }
          theme={theme}
        />
        <Row
          icon="📬"
          title="Weekly Reports"
          subtitle={weeklyReports ? 'Subscribed' : 'Unsubscribed'}
          right={
            <Switch
              value={weeklyReports}
              onValueChange={(v) => { tick(); setWeeklyReports(v); saveSetting({ weekly_reports: v }); }}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={darkMode ? '#f5dd4b' : '#f4f3f4'}
            />
          }
          border={false}
          theme={theme}
        />

        {/* Locale */}
        <SectionHeader title="Locale" theme={theme} />
        <Row
          icon="💱"
          title="Currency"
          subtitle={currency}
          onPress={() => {
            const options = ['ZAR', 'USD', 'EUR', 'GBP', 'Cancel'];
            Alert.alert('Currency', 'Choose display currency', [
              ...options.slice(0, -1).map(c => ({ text: c, onPress: () => { setCurrency(c); saveSetting({ currency: c }); } })),
              { text: 'Cancel', style: 'cancel' },
            ]);
          }}
          theme={theme}
        />
        <Row
          icon="🌐"
          title="Language"
          subtitle={language}
          onPress={() => {
            const opts = ['English', 'Afrikaans', 'Xhosa', 'Zulu', 'Cancel'];
            Alert.alert('Language', 'Choose app language', [
              ...opts.slice(0, -1).map(l => ({ text: l, onPress: () => { setLanguage(l); saveSetting({ language: l }); } })),
              { text: 'Cancel', style: 'cancel' },
            ]);
          }}
          border={false}
          theme={theme}
        />

        {/* Data & Privacy */}
        <SectionHeader title="Data & Privacy" theme={theme} />
        <Row icon="🧰" title="Backup Data" subtitle="Create a portable backup" onPress={handleBackup} theme={theme} />
        <Row icon="📤" title="Export Data" subtitle="Download your data (CSV)" onPress={handleExportData} theme={theme} />
        <Row icon="🔒" title="Privacy Policy" subtitle="Read our privacy policy" onPress={() => Linking.openURL(PRIVACY_URL)} theme={theme} />
        <Row icon="📜" title="Terms of Service" subtitle="Review our terms" onPress={() => Linking.openURL(TERMS_URL)} border={false} theme={theme} />

        {/* Support & About */}
        <SectionHeader title="Support & About" theme={theme} />
        <Row
          icon="❓"
          title="Help & FAQ"
          subtitle="Find answers to common questions"
          onPress={() => Linking.openURL(HELP_URL)}
          theme={theme}
        />
        <Row
          icon="📞"
          title="Contact Support"
          subtitle={SUPPORT_EMAIL}
          onPress={() => mailto(SUPPORT_EMAIL, `${APP_NAME} Support`, '')}
          theme={theme}
        />
        <Row
          icon="⭐"
          title="Rate App"
          subtitle="Rate us on the app store"
          onPress={() => setRateVisible(true)}
          theme={theme}
        />
        <Row
          icon="ℹ️"
          title="About"
          subtitle={`Version ${version}`}
          onPress={() => setAboutVisible(true)}
          border={false}
          theme={theme}
        />

        {/* Account Actions */}
        <SectionHeader title="Account Actions" theme={theme} />
        <Row
          icon="🚪"
          title="Sign Out"
          subtitle="Sign out of your account"
          onPress={() => {
            Alert.alert('Sign Out', 'Do you want to sign out?', [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Sign Out', style: 'destructive', onPress: () => signOut().catch(() => Alert.alert('Error', 'Failed to sign out.')) },
            ]);
          }}
          theme={theme}
        />
        <Row
          icon="🗑️"
          title="Delete Account"
          subtitle="Permanently delete your account data"
          onPress={handleDeleteAccount}
          danger
          border={false}
          theme={theme}
        />

        <View style={{ height: 24 }} />
      </ScrollView>

      {/* -------- Modals -------- */}

      {/* Edit Profile */}
      <Modal visible={profileModalVisible} animationType="slide" transparent onRequestClose={() => setProfileModalVisible(false)}>
        <View style={styles(theme).overlay}>
          <View style={styles(theme).card}>
            <Text style={styles(theme).cardTitle}>Edit Profile</Text>
            <TextInput
              placeholder="First name"
              placeholderTextColor={theme.textSecondary}
              value={editProfile.firstName}
              onChangeText={(v) => setEditProfile(s => ({ ...s, firstName: v }))}
              style={styles(theme).input}
            />
            <TextInput
              placeholder="Last name"
              placeholderTextColor={theme.textSecondary}
              value={editProfile.lastName}
              onChangeText={(v) => setEditProfile(s => ({ ...s, lastName: v }))}
              style={styles(theme).input}
            />
            <TextInput
              placeholder="Phone"
              placeholderTextColor={theme.textSecondary}
              value={editProfile.phone}
              onChangeText={(v) => setEditProfile(s => ({ ...s, phone: v }))}
              style={styles(theme).input}
              keyboardType="phone-pad"
            />
            <View style={styles(theme).rowActions}>
              <TouchableOpacity style={styles(theme).btnGhost} onPress={() => setProfileModalVisible(false)}>
                <Text style={styles(theme).btnGhostText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles(theme).btn} onPress={handleSaveProfile} disabled={saving}>
                <Text style={styles(theme).btnText}>{saving ? 'Saving…' : 'Save'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Change Password */}
      <ChangePasswordModal
        visible={pwdModalVisible}
        onClose={() => setPwdModalVisible(false)}
        onSubmit={handleChangePassword}
        theme={theme}
      />

      {/* Email Preferences */}
      <EmailPrefsModal
        visible={emailPrefsVisible}
        marketing={emailMarketing}
        product={emailProduct}
        onClose={() => setEmailPrefsVisible(false)}
        onChange={(m, p) => {
          setEmailMarketing(m);
          setEmailProduct(p);
          saveSetting({ email_marketing: m, email_product: p });
        }}
        theme={theme}
      />

      {/* Energy Threshold */}
      <Modal visible={energyModalVisible} animationType="fade" transparent onRequestClose={() => setEnergyModalVisible(false)}>
        <View style={styles(theme).overlay}>
          <View style={styles(theme).card}>
            <Text style={styles(theme).cardTitle}>Energy Threshold</Text>
            <Text style={styles(theme).cardSubtitle}>Set alert threshold (kWh)</Text>
            <TextInput
              value={energyThreshold}
              onChangeText={(v) => setEnergyThreshold(v.replace(/[^\d.]/g, ''))}
              keyboardType="numeric"
              style={styles(theme).input}
              placeholderTextColor={theme.textSecondary}
            />
            <View style={styles(theme).rowActions}>
              <TouchableOpacity style={styles(theme).btnGhost} onPress={() => setEnergyModalVisible(false)}>
                <Text style={styles(theme).btnGhostText}>Close</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles(theme).btn}
                onPress={() => { saveSetting({ energy_threshold: Number(energyThreshold || 0) }); setEnergyModalVisible(false); }}
              >
                <Text style={styles(theme).btnText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* About */}
      <Modal visible={aboutVisible} animationType="fade" transparent onRequestClose={() => setAboutVisible(false)}>
        <View style={styles(theme).overlay}>
          <View style={styles(theme).card}>
            <Text style={styles(theme).cardTitle}>About {APP_NAME}</Text>
            <Text style={styles(theme).cardSubtitle}>Version {version}</Text>
            <Text style={styles(theme).aboutText}>
              {APP_NAME} helps you monitor and optimize home energy usage.
            </Text>
            <TouchableOpacity style={[styles(theme).btn, { marginTop: 12 }]} onPress={() => setAboutVisible(false)}>
              <Text style={styles(theme).btnText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Rate App */}
      <RateAppModal
        visible={rateVisible}
        onClose={() => setRateVisible(false)}
        onSubmit={handleRateSubmit}
        theme={theme}
      />
    </>
  );
};

// --------- Change Password Modal ----------
const ChangePasswordModal = ({ visible, onClose, onSubmit, theme }) => {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');

  useEffect(() => {
    if (!visible) { setCurrent(''); setNext(''); setConfirm(''); }
  }, [visible]);

  return (
    <Modal visible={visible} animationType="fade" transparent onRequestClose={onClose}>
      <View style={styles(theme).overlay}>
        <View style={styles(theme).card}>
          <Text style={styles(theme).cardTitle}>Change Password</Text>
          <TextInput
            placeholder="Current password"
            placeholderTextColor={theme.textSecondary}
            secureTextEntry
            style={styles(theme).input}
            value={current}
            onChangeText={setCurrent}
          />
          <TextInput
            placeholder="New password (min 8)"
            placeholderTextColor={theme.textSecondary}
            secureTextEntry
            style={styles(theme).input}
            value={next}
            onChangeText={setNext}
          />
          <TextInput
            placeholder="Confirm new password"
            placeholderTextColor={theme.textSecondary}
            secureTextEntry
            style={styles(theme).input}
            value={confirm}
            onChangeText={setConfirm}
          />
          <View style={styles(theme).rowActions}>
            <TouchableOpacity style={styles(theme).btnGhost} onPress={onClose}>
              <Text style={styles(theme).btnGhostText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles(theme).btn} onPress={() => onSubmit(current, next, confirm)}>
              <Text style={styles(theme).btnText}>Update</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

// --------- Email Prefs Modal ----------
const EmailPrefsModal = ({ visible, marketing, product, onClose, onChange, theme }) => {
  const [m, setM] = useState(marketing);
  const [p, setP] = useState(product);

  useEffect(() => {
    setM(marketing); setP(product);
  }, [marketing, product, visible]);

  return (
    <Modal visible={visible} animationType="fade" transparent onRequestClose={onClose}>
      <View style={styles(theme).overlay}>
        <View style={styles(theme).card}>
          <Text style={styles(theme).cardTitle}>Email Preferences</Text>
          <Row
            icon="📰"
            title="Marketing emails"
            subtitle={m ? 'Subscribed' : 'Unsubscribed'}
            right={<Switch value={m} onValueChange={(v) => setM(v)} />}
            border
            theme={theme}
          />
          <Row
            icon="🛠️"
            title="Product updates"
            subtitle={p ? 'Subscribed' : 'Unsubscribed'}
            right={<Switch value={p} onValueChange={(v) => setP(v)} />}
            border={false}
            theme={theme}
          />
          <View style={styles(theme).rowActions}>
            <TouchableOpacity style={styles(theme).btnGhost} onPress={onClose}>
              <Text style={styles(theme).btnGhostText}>Close</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles(theme).btn}
              onPress={() => { onChange(m, p); onClose(); }}
            >
              <Text style={styles(theme).btnText}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

// --------- Rate App Modal ----------
const RateAppModal = ({ visible, onClose, onSubmit, theme }) => {
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState('');

  useEffect(() => {
    if (!visible) { setRating(0); setFeedback(''); }
  }, [visible]);

  const cta = rating >= 4 ? 'Rate on the Store' : 'Send Feedback';

  return (
    <Modal visible={visible} animationType="fade" transparent onRequestClose={onClose}>
      <View style={styles(theme).overlay}>
        <View style={styles(theme).card}>
          <Text style={styles(theme).cardTitle}>Enjoying {APP_NAME}?</Text>
          <Text style={styles(theme).cardSubtitle}>Tap to rate</Text>
          <View style={styles(theme).stars}>
            {[1,2,3,4,5].map(i => (
              <TouchableOpacity key={i} onPress={() => setRating(i)} style={{ padding: 4 }}>
                {star(rating >= i)}
              </TouchableOpacity>
            ))}
          </View>
          <TextInput
            placeholder={rating >= 4 ? 'Anything we should highlight?' : 'Tell us what to improve…'}
            placeholderTextColor={theme.textSecondary}
            style={styles(theme).input}
            multiline
            maxLength={800}
            value={feedback}
            onChangeText={setFeedback}
          />
          <View style={styles(theme).rowActions}>
            <TouchableOpacity style={styles(theme).btnGhost} onPress={onClose}>
              <Text style={styles(theme).btnGhostText}>Not now</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles(theme).btn}
              onPress={() => onSubmit(rating, feedback)}
              disabled={rating === 0}
            >
              <Text style={styles(theme).btnText}>{rating === 0 ? 'Pick stars' : cta}</Text>
            </TouchableOpacity>
          </View>
          {rating >= 4 && (!APP_STORE_ID || !PLAY_STORE_PACKAGE_NAME) ? (
            <Text style={styles(theme).hint}>
              Tip: set APP_STORE_ID (iOS) and PLAY_STORE_PACKAGE_NAME (Android) for direct review links.
            </Text>
          ) : null}
        </View>
      </View>
    </Modal>
  );
};

export default SettingsTab;

// ---------- Dynamic Styles ----------
const styles = (theme) => StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.background, paddingHorizontal: 14 },
  sectionHeader: { color: theme.textSecondary, marginTop: 20, marginBottom: 8, fontSize: 13, fontWeight: '700', textTransform: 'uppercase' },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12 },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: theme.border },
  rowLeft: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  rowIcon: { width: 28, textAlign: 'center', fontSize: 18 },
  rowTitle: { color: theme.text, fontSize: 15, fontWeight: '700' },
  rowSubtitle: { color: theme.textSecondary, fontSize: 12, marginTop: 2 },
  rowRight: { minWidth: 24, alignItems: 'flex-end' },
  disclosure: { color: theme.textSecondary, fontSize: 24, paddingHorizontal: 6 },

  overlay: { flex: 1, backgroundColor: theme.overlay, justifyContent: 'center', padding: 16 },
  card: { backgroundColor: theme.card, borderRadius: 16, borderWidth: 1, borderColor: theme.cardBorder, padding: 16 },
  cardTitle: { color: theme.text, fontSize: 18, fontWeight: '800' },
  cardSubtitle: { color: theme.textSecondary, fontSize: 13, marginTop: 6, marginBottom: 10 },
  input: {
    minHeight: 48,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: theme.inputBorder,
    backgroundColor: theme.inputBackground,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: theme.text,
    marginTop: 10,
    textAlignVertical: 'top',
  },
  rowActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10, marginTop: 14 },
  btn: { backgroundColor: theme.button, paddingVertical: 12, paddingHorizontal: 16, borderRadius: 12 },
  btnText: { color: theme.buttonText, fontSize: 14, fontWeight: '800' },
  btnGhost: { paddingVertical: 12, paddingHorizontal: 14, borderRadius: 12, borderWidth: 1, borderColor: theme.ghostButtonBorder },
  btnGhostText: { color: theme.ghostButtonText, fontSize: 14, fontWeight: '600' },
  stars: { flexDirection: 'row', justifyContent: 'center', marginVertical: 8, gap: 4 },
  hint: { color: theme.textSecondary, fontSize: 12, marginTop: 10 },
  aboutText: { color: theme.text, marginTop: 10, lineHeight: 20 },
});