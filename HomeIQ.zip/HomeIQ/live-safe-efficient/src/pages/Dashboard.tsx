import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Home,
  Zap,
  Shield,
  BarChart3,
  Settings,
  Plus,
  AlertTriangle,
  Camera,
  Mic,
  Power,
  ThermometerSun,
  Tv,
  Refrigerator,
  WashingMachine,
  Clock
} from "lucide-react";
import homeIQLogo from "@/assets/home-iq-logo.png";
import { ApplianceCard } from "@/components/ApplianceCard";
import { SecurityPanel } from "@/components/SecurityPanel";
import { AnalyticsPanel } from "@/components/AnalyticsPanel";
import { LucideIcon } from "lucide-react";

interface Appliance {
  id: string;
  name: string;
  type: string;
  icon: LucideIcon;
  currentUsage: number;
  normalUsage: number;
  status: "on" | "off";
  monthlyCost: number;
  energyLevel: "high" | "warning" | "normal" | "excellent";
}

// Mock appliance data
const mockAppliances: Appliance[] = [
  {
    id: "1",
    name: "Living Room Heater",
    type: "heater",
    icon: ThermometerSun,
    currentUsage: 2400,
    normalUsage: 2000,
    status: "on" as const,
    monthlyCost: 450,
    energyLevel: "high" as const
  },
  {
    id: "2",
    name: "Kitchen Refrigerator",
    type: "refrigerator",
    icon: Refrigerator,
    currentUsage: 150,
    normalUsage: 180,
    status: "on" as const,
    monthlyCost: 85,
    energyLevel: "excellent" as const
  },
  {
    id: "3",
    name: "Living Room TV",
    type: "tv",
    icon: Tv,
    currentUsage: 120,
    normalUsage: 100,
    status: "on" as const,
    monthlyCost: 65,
    energyLevel: "warning" as const
  },
  {
    id: "4",
    name: "Washing Machine",
    type: "washing-machine",
    icon: WashingMachine,
    currentUsage: 0,
    normalUsage: 500,
    status: "off" as const,
    monthlyCost: 0,
    energyLevel: "normal" as const
  }
];

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("appliances");
  const [appliances, setAppliances] = useState(mockAppliances);

  const totalCurrentUsage = appliances.reduce((sum, appliance) => sum + appliance.currentUsage, 0);
  const totalMonthlyCost = appliances.reduce((sum, appliance) => sum + appliance.monthlyCost, 0);

  const toggleAppliance = (id: string) => {
    setAppliances(prev => prev.map(appliance => 
      appliance.id === id 
        ? { 
            ...appliance, 
            status: appliance.status === "on" ? "off" as const : "on" as const,
            currentUsage: appliance.status === "on" ? 0 : appliance.normalUsage,
            monthlyCost: appliance.status === "on" ? 0 : Math.round(appliance.normalUsage * 0.35)
          }
        : appliance
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-accent/20 to-primary/5">
      {/* Header */}
      <header className="bg-card/50 backdrop-blur-lg border-b border-border/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={homeIQLogo} alt="Home IQ" className="w-10 h-10" />
              <div>
                <h1 className="text-xl font-bold text-foreground">Home IQ</h1>
                <p className="text-xs text-muted-foreground">Smart Dashboard</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Quick Stats */}
              <div className="hidden md:flex items-center gap-4 text-sm">
                <div className="text-center">
                  <p className="font-semibold text-foreground">{totalCurrentUsage}W</p>
                  <p className="text-muted-foreground">Current Usage</p>
                </div>
                <div className="text-center">
                  <p className="font-semibold text-foreground">R{totalMonthlyCost}</p>
                  <p className="text-muted-foreground">Monthly Cost</p>
                </div>
              </div>

              {/* Emergency Buttons */}
              <Button variant="emergency" size="sm">
                <AlertTriangle className="w-4 h-4" />
                PANIC
              </Button>
              
              <Button variant="outline" size="icon">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid bg-card/50 backdrop-blur-sm">
            <TabsTrigger value="appliances" className="flex items-center gap-2">
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">Appliances</span>
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              <span className="hidden sm:inline">Security</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Analytics</span>
            </TabsTrigger>
            <TabsTrigger value="controls" className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              <span className="hidden sm:inline">Controls</span>
            </TabsTrigger>
          </TabsList>

          {/* Appliances Tab */}
          <TabsContent value="appliances" className="space-y-6">
            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="glass">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Usage</p>
                      <p className="text-2xl font-bold text-foreground">{totalCurrentUsage}W</p>
                    </div>
                    <Zap className="w-8 h-8 text-primary" />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Monthly Cost</p>
                      <p className="text-2xl font-bold text-foreground">R{totalMonthlyCost}</p>
                    </div>
                    <BarChart3 className="w-8 h-8 text-energy-warning" />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Active Devices</p>
                      <p className="text-2xl font-bold text-foreground">
                        {appliances.filter(a => a.status === "on").length}
                      </p>
                    </div>
                    <Power className="w-8 h-8 text-energy-excellent" />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Efficiency</p>
                      <p className="text-2xl font-bold text-foreground">85%</p>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-energy-excellent/20 flex items-center justify-center">
                      <div className="w-4 h-4 rounded-full bg-energy-excellent" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Add Appliance Button */}
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-foreground">Your Appliances</h2>
              <Button variant="hero">
                <Plus className="w-4 h-4 mr-2" />
                Add Appliance
              </Button>
            </div>

            {/* Appliances Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {appliances.map((appliance) => (
                <ApplianceCard
                  key={appliance.id}
                  appliance={appliance}
                  onToggle={() => toggleAppliance(appliance.id)}
                />
              ))}
            </div>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security" className="space-y-6">
            <SecurityPanel />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <AnalyticsPanel appliances={appliances} />
          </TabsContent>

          {/* Controls Tab */}
          <TabsContent value="controls" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="glass">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Camera className="w-5 h-5" />
                    Camera Controls
                  </CardTitle>
                  <CardDescription>
                    Quick access to record security footage
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="hero" className="w-full">
                    <Camera className="w-4 h-4 mr-2" />
                    Start Recording
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Mic className="w-4 h-4 mr-2" />
                    Voice Recording
                  </Button>
                </CardContent>
              </Card>

              <Card className="glass">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Smart Scheduling
                  </CardTitle>
                  <CardDescription>
                    Set automated schedules for your appliances
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline" className="w-full">
                    Set Timer
                  </Button>
                  <Button variant="outline" className="w-full">
                    Schedule Routine
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Dashboard;