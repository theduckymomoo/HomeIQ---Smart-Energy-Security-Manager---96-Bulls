import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  RefreshControl,
  Alert,
  Dimensions,
  Animated,
  PanGestureHandler,
  State,
  Switch,
  Vibration,
  StatusBar,
} from 'react-native';
import { useAuth } from '../../Context/AuthContext';
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

const HomeTab = () => {
  const { user, userProfile, signOut, supabase } = useAuth();
  const navigation = useNavigation();
  const [appliances, setAppliances] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState('All');
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const [darkMode, setDarkMode] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  // Enhanced animations
  const [pulseAnim] = useState(new Animated.Value(1));
  const [slideAnim] = useState(new Animated.Value(0));
  const [scaleAnims] = useState({});
  const [rotateAnim] = useState(new Animated.Value(0));

  const [stats, setStats] = useState({
    totalUsage: 0,
    monthlyCost: 0,
    activeDevices: 0,
    efficiency: 85,
    peakHour: '7 PM',
    carbonFootprint: 0,
    savings: 0,
  });

  // Memoized calculations for better performance
  const filteredAppliances = useMemo(() => {
    if (selectedRoom === 'All') return appliances;
    return appliances.filter(app => app.room === selectedRoom);
  }, [appliances, selectedRoom]);

  const roomList = useMemo(() => {
    const rooms = [...new Set(appliances.map(app => app.room))];
    return ['All', ...rooms];
  }, [appliances]);

  const energyTrend = useMemo(() => {
    const currentUsage = stats.totalUsage;
    const previousUsage = Math.round(currentUsage * (0.85 + Math.random() * 0.3));
    return {
      change: currentUsage - previousUsage,
      percentage: Math.round(((currentUsage - previousUsage) / previousUsage) * 100)
    };
  }, [stats.totalUsage]);

  // Enhanced animations
  useEffect(() => {
    const animations = [
      // Breathing pulse animation
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.05,
            duration: 2000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 2000,
            useNativeDriver: true,
          }),
        ])
      ),
      // Slide in animation
      Animated.timing(slideAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      // Rotation animation for refresh
      Animated.loop(
        Animated.timing(rotateAnim, {
          toValue: 1,
          duration: 10000,
          useNativeDriver: true,
        })
      ),
    ];

    animations.forEach(anim => anim.start());

    return () => animations.forEach(anim => anim.stop());
  }, []);

  // Create scale animations for each appliance
  const createScaleAnim = useCallback((id) => {
    if (!scaleAnims[id]) {
      scaleAnims[id] = new Animated.Value(1);
    }
    return scaleAnims[id];
  }, [scaleAnims]);

  const animatePress = useCallback((id) => {
    const scaleAnim = createScaleAnim(id);
    Vibration.vibrate(50); // Haptic feedback
    
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  }, [createScaleAnim]);

  const getDisplayName = useCallback(() => {
    if (userProfile?.first_name) {
      return userProfile.first_name;
    }
    return user?.email?.split('@')[0] || 'User';
  }, [userProfile, user]);

  const getApplianceIcon = useCallback((type) => {
    const iconMap = {
      refrigerator: '❄️',
      tv: '📺',
      washing_machine: '🧺',
      air_conditioner: '💨',
      heater: '🔥',
      light: '💡',
      microwave: '🔥',
      dishwasher: '🍽️',
      computer: '💻',
      fan: '💨',
    };
    return iconMap[type.toLowerCase()] || '⚡';
  }, []);

  const getEnergyLevel = useCallback((usage) => {
    if (usage <= 50) return { label: 'Excellent', color: '#10b981', bgColor: 'rgba(16, 185, 129, 0.15)' };
    if (usage <= 100) return { label: 'Good', color: '#10b981', bgColor: 'rgba(16, 185, 129, 0.15)' };
    if (usage <= 200) return { label: 'Normal', color: '#f59e0b', bgColor: 'rgba(245, 158, 11, 0.15)' };
    if (usage <= 300) return { label: 'Warning', color: '#f97316', bgColor: 'rgba(249, 115, 22, 0.15)' };
    return { label: 'High', color: '#ef4444', bgColor: 'rgba(239, 68, 68, 0.15)' };
  }, []);

  const fetchAppliances = useCallback(async () => {
    if (!user?.id) return;

    try {
      const { data, error } = await supabase
        .from('appliances')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching appliances:', error);
        Alert.alert('Error', 'Failed to load appliances');
        return;
      }

      setAppliances(data || []);
      calculateStats(data || []);
    } catch (error) {
      console.error('Error in fetchAppliances:', error);
      Alert.alert('Error', 'Failed to load appliances');
    }
  }, [user?.id, supabase]);

  const calculateStats = useCallback((applianceList) => {
    const activeAppliances = applianceList.filter(app => app.status === 'on');
    const totalUsage = activeAppliances.reduce((sum, app) => sum + app.normal_usage, 0);

    const kWh = totalUsage / 1000;
    const hoursPerMonth = 24 * 30;
    const monthlyCost = kWh * hoursPerMonth * 2.50;

    const avgUsagePerDevice = totalUsage / Math.max(activeAppliances.length, 1);
    let efficiency = 100;
    if (avgUsagePerDevice > 300) efficiency = 60;
    else if (avgUsagePerDevice > 200) efficiency = 70;
    else if (avgUsagePerDevice > 100) efficiency = 80;
    else efficiency = 90;

    // Calculate carbon footprint (kg CO2 per kWh in South Africa ≈ 0.93)
    const carbonFootprint = Math.round(kWh * hoursPerMonth * 0.93);
    
    // Calculate potential savings
    const potentialSavings = Math.round(monthlyCost * 0.15);

    setStats({
      totalUsage: Math.round(totalUsage),
      monthlyCost: Math.round(monthlyCost),
      activeDevices: activeAppliances.length,
      efficiency,
      carbonFootprint,
      savings: potentialSavings,
    });
  }, []);

  const toggleAppliance = useCallback(async (applianceId, currentStatus) => {
    const newStatus = currentStatus === 'on' ? 'off' : 'on';
    
    animatePress(applianceId);

    try {
      const { error } = await supabase
        .from('appliances')
        .update({ status: newStatus })
        .eq('id', applianceId);

      if (error) {
        console.error('Error updating appliance:', error);
        Alert.alert('Error', 'Failed to update appliance status');
        return;
      }

      const updatedAppliances = appliances.map(app =>
        app.id === applianceId ? { ...app, status: newStatus } : app
      );
      setAppliances(updatedAppliances);
      calculateStats(updatedAppliances);
    } catch (error) {
      console.error('Error in toggleAppliance:', error);
      Alert.alert('Error', 'Failed to update appliance status');
    }
  }, [appliances, supabase, animatePress, calculateStats]);

  const bulkToggleDevices = useCallback(async (type, status) => {
    const devicesToUpdate = appliances.filter(app => 
      type === 'all' || app.type === type
    );

    if (devicesToUpdate.length === 0) {
      Alert.alert('Info', `No ${type} devices found`);
      return;
    }

    try {
      const updatePromises = devicesToUpdate.map(device =>
        supabase
          .from('appliances')
          .update({ status })
          .eq('id', device.id)
      );

      await Promise.all(updatePromises);

      const updatedAppliances = appliances.map(app =>
        devicesToUpdate.some(device => device.id === app.id)
          ? { ...app, status }
          : app
      );

      setAppliances(updatedAppliances);
      calculateStats(updatedAppliances);
      
      Vibration.vibrate(100);
      Alert.alert('Success', `Turned ${status} ${devicesToUpdate.length} ${type} devices`);
    } catch (error) {
      console.error('Error in bulk toggle:', error);
      Alert.alert('Error', 'Failed to update devices');
    }
  }, [appliances, supabase, calculateStats]);

  const activateAwayMode = useCallback(async () => {
    const essentialTypes = ['refrigerator', 'heater']; // Keep these on
    const nonEssentialDevices = appliances.filter(app => 
      !essentialTypes.includes(app.type) && app.status === 'on'
    );

    if (nonEssentialDevices.length === 0) {
      Alert.alert('Info', 'No non-essential devices are currently active');
      return;
    }

    Alert.alert(
      'Away Mode',
      `This will turn off ${nonEssentialDevices.length} non-essential devices. Essential devices like refrigerators will remain on.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Activate',
          onPress: async () => {
            await bulkToggleDevices('all', 'off');
            // Turn back on essential devices
            for (const device of appliances.filter(app => essentialTypes.includes(app.type))) {
              await toggleAppliance(device.id, 'off'); // This will turn it on
            }
          },
        },
      ]
    );
  }, [appliances, bulkToggleDevices, toggleAppliance]);

  const getRecentActivity = useCallback(() => {
    // Enhanced activity with more realistic data
    return [
      { 
        icon: '💡', 
        action: 'Living Room Light turned on', 
        time: '5 mins ago', 
        impact: '+50W',
        type: 'device_on',
        room: 'Living Room'
      },
      { 
        icon: '📺', 
        action: 'TV turned off', 
        time: '1 hour ago', 
        impact: '-120W',
        type: 'device_off',
        room: 'Living Room'
      },
      { 
        icon: '❄️', 
        action: 'AC temperature adjusted', 
        time: '2 hours ago', 
        impact: '-50W',
        type: 'optimization',
        room: 'Bedroom'
      },
      { 
        icon: '🔌', 
        action: 'New device added: Smart Plug', 
        time: '4 hours ago', 
        impact: '+0W',
        type: 'device_added',
        room: 'Kitchen'
      },
    ];
  }, []);

  const handlePanic = useCallback(() => {
    Alert.alert(
      'EMERGENCY ALERT',
      'This will send an emergency notification to your emergency contacts. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'SEND ALERT',
          style: 'destructive',
          onPress: () => {
            Vibration.vibrate([100, 50, 100, 50, 100]);
            Alert.alert('Emergency Alert Sent', 'Your emergency contacts have been notified.');
          },
        },
      ]
    );
  }, []);

  const navigateToProfile = useCallback(() => {
    navigation.navigate('Setting');
  }, [navigation]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchAppliances();
    setRefreshing(false);
  }, [fetchAppliances]);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await fetchAppliances();
      setLoading(false);
    };

    if (user?.id) {
      loadData();
    }
  }, [user?.id, fetchAppliances]);

  const getRoomStats = useCallback(() => {
    const roomStats = {};
    appliances.forEach(app => {
      if (!roomStats[app.room]) {
        roomStats[app.room] = {
          name: app.room,
          totalUsage: 0,
          deviceCount: 0,
          activeDevices: 0
        };
      }
      roomStats[app.room].totalUsage += app.normal_usage;
      roomStats[app.room].deviceCount += 1;
      if (app.status === 'on') {
        roomStats[app.room].activeDevices += 1;
      }
    });
    return Object.values(roomStats);
  }, [appliances]);

  const renderQuickStats = () => (
    <View style={styles.quickStats}>
      <Animated.View style={[styles.statCard, { transform: [{ scale: pulseAnim }] }]}>
        <Text style={styles.statIcon}>⚡</Text>
        <Text style={styles.statValue}>{stats.totalUsage}W</Text>
        <Text style={styles.statLabel}>Current Usage</Text>
        <View style={styles.statTrend}>
          <Text style={[styles.statTrendText, { 
            color: energyTrend.change > 0 ? '#ef4444' : '#10b981' 
          }]}>
            {energyTrend.change > 0 ? '↗️' : '↘️'} {energyTrend.percentage}%
          </Text>
        </View>
      </Animated.View>

      <TouchableOpacity style={styles.statCard} activeOpacity={0.8}>
        <Text style={styles.statIcon}>💰</Text>
        <Text style={styles.statValue}>R{stats.monthlyCost}</Text>
        <Text style={styles.statLabel}>Monthly Cost</Text>
        <View style={styles.statTrend}>
          <Text style={styles.statTrendText}>Save R{stats.savings}/mo</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity style={styles.statCard} activeOpacity={0.8}>
        <Text style={styles.statIcon}>🌱</Text>
        <Text style={styles.statValue}>{stats.carbonFootprint}kg</Text>
        <Text style={styles.statLabel}>CO₂/month</Text>
        <View style={styles.statTrend}>
          <Text style={styles.statTrendText}>Carbon footprint</Text>
        </View>
      </TouchableOpacity>
    </View>
  );

  const renderRoomFilter = () => (
    <View style={styles.roomFilter}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {roomList.map((room) => (
          <TouchableOpacity
            key={room}
            style={[
              styles.roomFilterButton,
              selectedRoom === room && styles.roomFilterButtonActive
            ]}
            onPress={() => setSelectedRoom(room)}
            activeOpacity={0.7}
          >
            <Text style={[
              styles.roomFilterText,
              selectedRoom === room && styles.roomFilterTextActive
            ]}>
              {room}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );

  const renderEnhancedDeviceCard = (item) => {
    const energyLevel = getEnergyLevel(item.normal_usage);
    const scaleAnim = createScaleAnim(item.id);

    return (
      <Animated.View
        key={item.id}
        style={[
          styles.enhancedDeviceCard,
          { 
            width: viewMode === 'grid' ? '47%' : '100%',
            transform: [{ scale: scaleAnim }],
            backgroundColor: energyLevel.bgColor,
            borderColor: energyLevel.color,
          }
        ]}
      >
        <TouchableOpacity
          onPress={() => toggleAppliance(item.id, item.status)}
          activeOpacity={0.8}
          style={styles.deviceCardContent}
        >
          <View style={styles.deviceCardHeader}>
            <Text style={styles.deviceIcon}>{getApplianceIcon(item.type)}</Text>
            <View style={styles.deviceStatusContainer}>
              <Switch
                value={item.status === 'on'}
                onValueChange={() => toggleAppliance(item.id, item.status)}
                trackColor={{ false: '#4b5563', true: energyLevel.color }}
                thumbColor={item.status === 'on' ? '#f8fafc' : '#f8fafc'}
              />
            </View>
          </View>
          
          <Text style={styles.deviceName}>{item.name}</Text>
          <Text style={styles.deviceRoom}>📍 {item.room}</Text>
          
          <View style={styles.deviceStats}>
            <View style={styles.deviceStatItem}>
              <Text style={styles.deviceUsage}>{item.normal_usage}W</Text>
              <Text style={styles.deviceUsageLabel}>Power</Text>
            </View>
            <View style={styles.deviceStatItem}>
              <Text style={[styles.energyLevelText, { color: energyLevel.color }]}>
                {energyLevel.label}
              </Text>
              <Text style={styles.deviceUsageLabel}>Efficiency</Text>
            </View>
          </View>

          <View style={styles.deviceProgressBar}>
            <View 
              style={[
                styles.deviceProgress, 
                { 
                  width: `${Math.min((item.normal_usage / 400) * 100, 100)}%`,
                  backgroundColor: energyLevel.color 
                }
              ]} 
            />
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0b" />
      <ScrollView
        refreshControl={
          <RefreshControl 
            refreshing={refreshing} 
            onRefresh={onRefresh} 
            colors={['#10b981']}
            progressBackgroundColor="#1f2937"
          />
        }
        showsVerticalScrollIndicator={false}
        style={[styles.container, { backgroundColor: darkMode ? '#0a0a0b' : '#f5f5f5' }]}
      >
        {/* Enhanced Header */}
        <Animated.View 
          style={[
            styles.header, 
            { 
              transform: [{ 
                translateY: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [-50, 0]
                })
              }] 
            }
          ]}
        >
          <View style={styles.headerContent}>
            <View>
              <Text style={styles.greeting}>
                {new Date().getHours() < 12 ? 'Good morning' : 
                 new Date().getHours() < 18 ? 'Good afternoon' : 'Good evening'}
              </Text>
              <Text style={styles.userName}>{getDisplayName()}</Text>
              <Text style={styles.energyStatus}>
                {stats.totalUsage > 300 ? '🔴 High usage detected' :
                 stats.totalUsage > 150 ? '🟡 Normal usage' : '🟢 Efficient usage'}
              </Text>
            </View>
            <View style={styles.headerButtons}>
              <TouchableOpacity
                style={styles.profileButton}
                onPress={navigateToProfile}
                activeOpacity={0.7}
              >
                <View style={styles.profileIcon}>
                  <Text style={styles.profileInitial}>
                    {getDisplayName().charAt(0).toUpperCase()}
                  </Text>
                </View>
              </TouchableOpacity>
              <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
                <TouchableOpacity style={styles.panicButton} onPress={handlePanic}>
                  <Text style={styles.panicText}>SOS</Text>
                </TouchableOpacity>
              </Animated.View>
            </View>
          </View>
        </Animated.View>

        {/* Enhanced Energy Banner */}
        <Animated.View 
          style={[
            styles.energyBanner,
            { 
              transform: [{ 
                translateX: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [-width, 0]
                })
              }] 
            }
          ]}
        >
          <View style={styles.energyBannerContent}>
            <Animated.View 
              style={[
                styles.energyStatusIcon,
                { 
                  transform: [{ 
                    rotate: rotateAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: ['0deg', '360deg']
                    })
                  }] 
                }
              ]}
            >
              <Text style={styles.energyStatusEmoji}>⚡</Text>
            </Animated.View>
            <View style={styles.energyStatusText}>
              <Text style={styles.energyStatusTitle}>
                {stats.totalUsage > 300 ? 'High Usage Alert' :
                  stats.totalUsage > 150 ? 'Normal Usage' : 'Efficient Usage'}
              </Text>
              <Text style={styles.energyStatusSubtitle}>
                {stats.totalUsage > 300 ? 'Consider optimizing your devices' :
                  stats.totalUsage > 150 ? 'Your consumption is within normal range' :
                    'Excellent! You\'re saving energy and money'}
              </Text>
            </View>
            <TouchableOpacity 
              style={styles.energyOptimizeButton} 
              activeOpacity={0.8}
              onPress={() => setShowAdvanced(!showAdvanced)}
            >
              <Text style={styles.energyOptimizeText}>
                {showAdvanced ? 'Hide' : 'Advanced'}
              </Text>
            </TouchableOpacity>
          </View>
        </Animated.View>

        {/* Enhanced Quick Stats */}
        {renderQuickStats()}

        {/* Advanced Controls (Collapsible) */}
        {showAdvanced && (
          <Animated.View style={styles.advancedControls}>
            <Text style={styles.sectionTitle}>Advanced Controls</Text>
            <View style={styles.advancedGrid}>
              <TouchableOpacity 
                style={styles.advancedCard}
                onPress={() => bulkToggleDevices('all', 'off')}
              >
                <Text style={styles.advancedIcon}>🔴</Text>
                <Text style={styles.advancedTitle}>Emergency Off</Text>
                <Text style={styles.advancedSubtitle}>Turn off all devices</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.advancedCard}
                onPress={() => Alert.alert('Smart Schedule', 'Feature coming soon!')}
              >
                <Text style={styles.advancedIcon}>🕒</Text>
                <Text style={styles.advancedTitle}>Smart Schedule</Text>
                <Text style={styles.advancedSubtitle}>Automated control</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.advancedCard}
                onPress={() => Alert.alert('Energy Report', 'Detailed report generated!')}
              >
                <Text style={styles.advancedIcon}>📊</Text>
                <Text style={styles.advancedTitle}>Energy Report</Text>
                <Text style={styles.advancedSubtitle}>Detailed analysis</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.advancedCard}
                onPress={activateAwayMode}
              >
                <Text style={styles.advancedIcon}>🏠</Text>
                <Text style={styles.advancedTitle}>Away Mode</Text>
                <Text style={styles.advancedSubtitle}>Smart automation</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        )}

        {/* Room Filter */}
        {renderRoomFilter()}

        {/* View Mode Toggle */}
        <View style={styles.viewModeToggle}>
          <Text style={styles.sectionTitle}>
            {selectedRoom === 'All' ? 'All Devices' : `${selectedRoom} Devices`} ({filteredAppliances.length})
          </Text>
          <View style={styles.viewModeButtons}>
            <TouchableOpacity
              style={[styles.viewModeButton, viewMode === 'grid' && styles.viewModeButtonActive]}
              onPress={() => setViewMode('grid')}
            >
              <Text style={styles.viewModeIcon}>⊞</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.viewModeButton, viewMode === 'list' && styles.viewModeButtonActive]}
              onPress={() => setViewMode('list')}
            >
              <Text style={styles.viewModeIcon}>≡</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Enhanced Devices Grid/List */}
        <View style={styles.section}>
          <View style={[
            styles.devicesContainer,
            viewMode === 'grid' ? styles.devicesGrid : styles.devicesList
          ]}>
            {filteredAppliances.map((item) => renderEnhancedDeviceCard(item))}
            {filteredAppliances.length === 0 && (
              <View style={styles.noDevicesContainer}>
                <Text style={styles.noDevicesIcon}>🔌</Text>
                <Text style={styles.noDevicesText}>
                  {selectedRoom === 'All' ? 'No devices found' : `No devices in ${selectedRoom}`}
                </Text>
                <TouchableOpacity 
                  style={styles.addDeviceButton}
                  onPress={() => navigation.navigate('AddDevice')}
                >
                  <Text style={styles.addDeviceText}>+ Add Device</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>

        {/* Enhanced Room Overview */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Room Overview</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {getRoomStats().map((room, index) => (
              <TouchableOpacity
                key={room.name}
                style={[
                  styles.roomOverviewCard,
                  selectedRoom === room.name && styles.roomOverviewCardActive
                ]}
                onPress={() => setSelectedRoom(room.name)}
                activeOpacity={0.8}
              >
                <View style={styles.roomOverviewHeader}>
                  <Text style={styles.roomOverviewIcon}>🏠</Text>
                  <Text style={styles.roomOverviewDeviceCount}>{room.deviceCount}</Text>
                </View>
                <Text style={styles.roomOverviewName}>{room.name}</Text>
                <Text style={styles.roomOverviewUsage}>{room.totalUsage}W</Text>
                <View style={[styles.roomOverviewStatus,
                { backgroundColor: room.activeDevices > 0 ? 'rgba(16, 185, 129, 0.2)' : 'rgba(107, 114, 128, 0.2)' }
                ]}>
                  <Text style={[styles.roomOverviewStatusText,
                  { color: room.activeDevices > 0 ? '#10b981' : '#9ca3af' }
                  ]}>
                    {room.activeDevices > 0 ? `${room.activeDevices} Active` : 'Inactive'}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Enhanced Recent Activity with Interactive Elements */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Activity</Text>
            <TouchableOpacity style={styles.clearAllButton} activeOpacity={0.8}>
              <Text style={styles.clearAllText}>Clear All</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.activityList}>
            {getRecentActivity().map((activity, index) => (
              <TouchableOpacity key={index} style={styles.activityItem} activeOpacity={0.8}>
                <View style={[styles.activityIcon, { backgroundColor: activity.type === 'device_on' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)' }]}>
                  <Text style={styles.activityIconText}>{activity.icon}</Text>
                </View>
                <View style={styles.activityContent}>
                  <Text style={styles.activityText}>{activity.action}</Text>
                  <Text style={styles.activityTime}>{activity.time} • {activity.room}</Text>
                </View>
                <View style={styles.activityImpact}>
                  <Text style={[styles.activityImpactText,
                  { color: activity.impact.startsWith('+') ? '#ef4444' : '#10b981' }
                  ]}>
                    {activity.impact}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Enhanced Energy Insights with Interactive Charts */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Energy Insights</Text>
          <View style={styles.insightsContainer}>
            <TouchableOpacity style={styles.insightCard} activeOpacity={0.8}>
              <View style={styles.insightHeader}>
                <Text style={styles.insightIcon}>📊</Text>
                <Text style={styles.insightTitle}>Peak Usage Hours</Text>
              </View>
              <Text style={styles.insightDescription}>
                Your highest usage is typically between 6-9 PM
              </Text>
              <View style={styles.insightChart}>
                <View style={styles.chartBar} />
                <View style={[styles.chartBar, { height: 20, backgroundColor: '#10b981' }]} />
                <View style={[styles.chartBar, { height: 35, backgroundColor: '#f59e0b' }]} />
                <View style={[styles.chartBar, { height: 45, backgroundColor: '#ef4444' }]} />
                <View style={[styles.chartBar, { height: 25, backgroundColor: '#10b981' }]} />
              </View>
              <Text style={styles.insightAction}>View Detailed Chart →</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.insightCard} activeOpacity={0.8}>
              <View style={styles.insightHeader}>
                <Text style={styles.insightIcon}>💡</Text>
                <Text style={styles.insightTitle}>Smart Optimization</Text>
              </View>
              <Text style={styles.insightDescription}>
                Turn off standby devices to save R{Math.round(stats.monthlyCost * 0.12)}/month
              </Text>
              <View style={styles.optimizationButtons}>
                <TouchableOpacity style={styles.optimizeButton}>
                  <Text style={styles.optimizeButtonText}>Auto Optimize</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.scheduleButton}>
                  <Text style={styles.scheduleButtonText}>Schedule</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.insightCard} activeOpacity={0.8}>
              <View style={styles.insightHeader}>
                <Text style={styles.insightIcon}>🌱</Text>
                <Text style={styles.insightTitle}>Carbon Impact</Text>
              </View>
              <Text style={styles.insightDescription}>
                Your monthly carbon footprint: {stats.carbonFootprint}kg CO₂
              </Text>
              <View style={styles.carbonProgress}>
                <View style={styles.carbonBar}>
                  <View style={[styles.carbonFill, { width: `${Math.min(stats.carbonFootprint / 50, 100)}%` }]} />
                </View>
                <Text style={styles.carbonText}>
                  {stats.carbonFootprint < 25 ? 'Excellent! 🌟' : 
                   stats.carbonFootprint < 50 ? 'Good 👍' : 'Room for improvement 📈'}
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* Interactive Weather-Based Recommendations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Smart Recommendations</Text>
          <View style={styles.weatherTipCard}>
            <View style={styles.weatherTipHeader}>
              <Text style={styles.weatherTipIcon}>🌤️</Text>
              <View style={styles.weatherInfo}>
                <Text style={styles.weatherTipTemp}>24°C</Text>
                <Text style={styles.weatherTipDescription}>Sunny • Low humidity • Light breeze</Text>
              </View>
              <TouchableOpacity style={styles.weatherRefresh}>
                <Text style={styles.weatherRefreshText}>🔄</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.weatherTipAction}>
              Perfect weather to turn off AC and open windows. Potential savings: R{Math.round(stats.monthlyCost * 0.3)} today!
            </Text>
            <View style={styles.weatherActions}>
              <TouchableOpacity 
                style={styles.weatherTipButton} 
                activeOpacity={0.8}
                onPress={() => bulkToggleDevices('air_conditioner', 'off')}
              >
                <Text style={styles.weatherTipButtonText}>Turn Off AC</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.weatherScheduleButton}>
                <Text style={styles.weatherScheduleText}>Schedule Later</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Quick Actions Floating Panel */}
        <View style={styles.quickActionsPanel}>
          <Text style={styles.quickActionTitle}>Quick Actions</Text>
          <View style={styles.quickActionButtons}>
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={() => bulkToggleDevices('light', 'off')}
            >
              <Text style={styles.quickActionIcon}>💡</Text>
              <Text style={styles.quickActionText}>All Lights Off</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={() => Alert.alert('Good Night', 'Good night mode activated!')}
            >
              <Text style={styles.quickActionIcon}>🌙</Text>
              <Text style={styles.quickActionText}>Good Night</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={() => Alert.alert('Movie Mode', 'Entertainment mode activated!')}
            >
              <Text style={styles.quickActionIcon}>🎬</Text>
              <Text style={styles.quickActionText}>Movie Mode</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.quickActionButton}
              onPress={() => Alert.alert('Party Mode', 'Party mode activated!')}
            >
              <Text style={styles.quickActionIcon}>🎉</Text>
              <Text style={styles.quickActionText}>Party Mode</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* App Footer */}
        <View style={styles.appFooter}>
          <View style={styles.footerStats}>
            <Text style={styles.footerTitle}>Energy Monitoring Dashboard</Text>
            <Text style={styles.footerSubtitle}>
              Last updated: {new Date().toLocaleTimeString()} • {appliances.length} devices connected
            </Text>
          </View>
          <TouchableOpacity style={styles.footerButton}>
            <Text style={styles.footerButtonText}>Settings ⚙️</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0b',
  },
  header: {
    padding: 24,
    paddingTop: 12,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  greeting: {
    fontSize: 16,
    color: '#d1d5db',
    marginBottom: 4,
  },
  userName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#ffffff',
  },
  energyStatus: {
    fontSize: 12,
    color: '#d1d5db',
    marginTop: 2,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  profileButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 20,
    padding: 2,
  },
  profileIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#10b981',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInitial: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  panicButton: {
    backgroundColor: '#ef4444',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  panicText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 12,
  },
  
  // Energy Banner
  energyBanner: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    marginHorizontal: 24,
    padding: 16,
    borderRadius: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  energyBannerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  energyStatusIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  energyStatusEmoji: {
    fontSize: 24,
  },
  energyStatusText: {
    flex: 1,
    marginRight: 12,
  },
  energyStatusTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 4,
  },
  energyStatusSubtitle: {
    fontSize: 12,
    color: '#d1d5db',
  },
  energyOptimizeButton: {
    backgroundColor: '#10b981',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  energyOptimizeText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 12,
  },

  // Enhanced Quick Stats
  quickStats: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  statIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 11,
    color: '#d1d5db',
    textAlign: 'center',
  },
  statTrend: {
    marginTop: 4,
  },
  statTrendText: {
    fontSize: 10,
    fontWeight: 'bold',
  },

  // Advanced Controls
  advancedControls: {
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  advancedGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
  },
  advancedCard: {
    width: '47%',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  advancedIcon: {
    fontSize: 28,
    marginBottom: 8,
  },
  advancedTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 4,
  },
  advancedSubtitle: {
    fontSize: 12,
    color: '#d1d5db',
    textAlign: 'center',
  },

  // Room Filter
  roomFilter: {
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  roomFilterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  roomFilterButtonActive: {
    backgroundColor: '#10b981',
    borderColor: '#10b981',
  },
  roomFilterText: {
    color: '#d1d5db',
    fontSize: 14,
    fontWeight: '600',
  },
  roomFilterTextActive: {
    color: '#ffffff',
  },

  // View Mode Toggle
  viewModeToggle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  viewModeButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  viewModeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  viewModeButtonActive: {
    backgroundColor: '#10b981',
    borderColor: '#10b981',
  },
  viewModeIcon: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },

  // Sections
  section: {
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffffff',
  },

  // Enhanced Device Cards
  devicesContainer: {
    gap: 16,
  },
  devicesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  devicesList: {
    flexDirection: 'column',
  },
  enhancedDeviceCard: {
    borderRadius: 16,
    padding: 16,
    borderWidth: 1.5,
    marginBottom: 16,
  },
  deviceCardContent: {
    flex: 1,
  },
  deviceCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  deviceIcon: {
    fontSize: 28,
  },
  deviceStatusContainer: {
    transform: [{ scale: 0.8 }],
  },
  deviceName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 4,
  },
  deviceRoom: {
    fontSize: 12,
    color: '#d1d5db',
    marginBottom: 12,
  },
  deviceStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  deviceStatItem: {
    alignItems: 'center',
  },
  deviceUsage: {
    fontSize: 14,
    fontWeight: '700',
    color: '#ffffff',
  },
  deviceUsageLabel: {
    fontSize: 10,
    color: '#d1d5db',
    marginTop: 2,
  },
  energyLevelText: {
    fontSize: 12,
    fontWeight: '700',
  },
  deviceProgressBar: {
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  deviceProgress: {
    height: '100%',
    borderRadius: 2,
  },

  // No Devices
  noDevicesContainer: {
    alignItems: 'center',
    padding: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  noDevicesIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  noDevicesText: {
    color: '#d1d5db',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 16,
  },
  addDeviceButton: {
    backgroundColor: '#10b981',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 24,
  },
  addDeviceText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '700',
  },

  // Room Overview
  roomOverviewCard: {
    width: width * 0.4,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 16,
    padding: 16,
    marginRight: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  roomOverviewCardActive: {
    borderColor: '#10b981',
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
  },
  roomOverviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  roomOverviewIcon: {
    fontSize: 24,
  },
  roomOverviewDeviceCount: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffffff',
  },
  roomOverviewName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 4,
  },
  roomOverviewUsage: {
    fontSize: 12,
    color: '#d1d5db',
    marginBottom: 8,
  },
  roomOverviewStatus: {
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    alignSelf: 'flex-start',
  },
  roomOverviewStatusText: {
    fontSize: 10,
    fontWeight: '700',
  },

  // Enhanced Activity
  activityList: {
    gap: 12,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  activityIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  activityIconText: {
    fontSize: 18,
  },
  activityContent: {
    flex: 1,
  },
  activityText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 2,
  },
  activityTime: {
    fontSize: 12,
    color: '#d1d5db',
  },
  activityImpact: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
  },
  activityImpactText: {
    fontSize: 12,
    fontWeight: '700',
  },
  clearAllButton: {
    padding: 4,
  },
  clearAllText: {
    color: '#d1d5db',
    fontSize: 14,
    fontWeight: '600',
  },

  // Enhanced Insights
  insightsContainer: {
    gap: 16,
  },
  insightCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  insightHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  insightIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  insightTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
  },
  insightDescription: {
    fontSize: 14,
    color: '#d1d5db',
    marginBottom: 12,
  },
  insightAction: {
    fontSize: 12,
    color: '#10b981',
    fontWeight: '600',
  },
  insightChart: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: 50,
    marginBottom: 12,
  },
  chartBar: {
    width: '18%',
    backgroundColor: '#6b7280',
    borderRadius: 4,
    height: 15,
  },
  optimizationButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  optimizeButton: {
    backgroundColor: '#10b981',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    flex: 1,
  },
  optimizeButtonText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
  },
  scheduleButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    flex: 1,
  },
  scheduleButtonText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
  },
  carbonProgress: {
    gap: 8,
  },
  carbonBar: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  carbonFill: {
    height: '100%',
    backgroundColor: '#10b981',
    borderRadius: 4,
  },
  carbonText: {
    fontSize: 12,
    color: '#10b981',
    fontWeight: '600',
  },

  // Enhanced Weather Tips
  weatherTipCard: {
    backgroundColor: 'rgba(59, 130, 246, 0.15)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.3)',
  },
  weatherTipHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  weatherTipIcon: {
    fontSize: 40,
    marginRight: 12,
  },
  weatherInfo: {
    flex: 1,
  },
  weatherTipTemp: {
    fontSize: 24,
    fontWeight: '700',
    color: '#ffffff',
  },
  weatherTipDescription: {
    fontSize: 14,
    color: '#d1d5db',
  },
  weatherRefresh: {
    padding: 8,
  },
  weatherRefreshText: {
    fontSize: 16,
    color: '#d1d5db',
  },
  weatherTipAction: {
    fontSize: 14,
    color: '#ffffff',
    lineHeight: 20,
    marginBottom: 12,
  },
  weatherActions: {
    flexDirection: 'row',
    gap: 8,
  },
  weatherTipButton: {
    backgroundColor: '#3b82f6',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 20,
    flex: 1,
  },
  weatherTipButtonText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 14,
    textAlign: 'center',
  },
  weatherScheduleButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 20,
    flex: 1,
  },
  weatherScheduleText: {
    color: '#ffffff',
    fontWeight: '600',
    fontSize: 14,
    textAlign: 'center',
  },

  // Quick Actions Panel
  quickActionsPanel: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    marginHorizontal: 24,
    padding: 16,
    borderRadius: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  quickActionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 12,
  },
  quickActionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
  },
  quickActionButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
  },
  quickActionIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  quickActionText: {
    fontSize: 10,
    color: '#ffffff',
    fontWeight: '600',
    textAlign: 'center',
  },

  // App Footer
  appFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    marginBottom: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.15)',
  },
  footerStats: {
    flex: 1,
  },
  footerTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: '#ffffff',
  },
  footerSubtitle: {
    fontSize: 10,
    color: '#d1d5db',
    marginTop: 2,
  },
  footerButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  footerButtonText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
  },
});

export default HomeTab;