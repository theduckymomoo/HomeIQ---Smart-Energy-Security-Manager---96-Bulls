import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Switch,
  Alert,
  TextInput,
  Modal,
  Dimensions,
  StatusBar,
  Vibration,
  Share,
  Linking,
} from 'react-native';
import { useAuth } from '../../Context/AuthContext';
import { useNavigation } from '@react-navigation/native';
import createStyles from './styles/SettingsStyles';

const { width, height } = Dimensions.get('window');

const SettingsTab = () => {
  const { user, userProfile, signOut, supabase, updateProfile } = useAuth();
  const navigation = useNavigation();
  
  // Settings State
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [energyAlerts, setEnergyAlerts] = useState(true);
  const [weeklyReports, setWeeklyReports] = useState(true);
  const [autoOptimization, setAutoOptimization] = useState(false);
  const [hapticFeedback, setHapticFeedback] = useState(true);
  const [energyThreshold, setEnergyThreshold] = useState('300');
  const [currency, setCurrency] = useState('ZAR');
  const [language, setLanguage] = useState('English');
  
  // Modal States
  const [profileModalVisible, setProfileModalVisible] = useState(false);
  const [energyModalVisible, setEnergyModalVisible] = useState(false);
  const [aboutModalVisible, setAboutModalVisible] = useState(false);
  const [backupModalVisible, setBackupModalVisible] = useState(false);
  
  // Profile Edit State
  const [editProfile, setEditProfile] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
  });

  const [appStats, setAppStats] = useState({
    totalDevices: 0,
    dataUsage: '2.4 MB',
    lastBackup: 'Never',
    memberSince: 'January 2024',
  });

  useEffect(() => {
    loadUserSettings();
    loadAppStats();
  }, []);

  const loadUserSettings = useCallback(async () => {
    if (userProfile) {
      setEditProfile({
        firstName: userProfile.first_name || '',
        lastName: userProfile.last_name || '',
        email: user?.email || '',
        phone: userProfile.phone || '',
      });
    }
  }, [userProfile, user]);

  const loadAppStats = useCallback(async () => {
    try {
      const { data: devices } = await supabase
        .from('appliances')
        .select('id')
        .eq('user_id', user?.id);
      
      setAppStats(prev => ({
        ...prev,
        totalDevices: devices?.length || 0,
      }));
    } catch (error) {
      console.error('Error loading app stats:', error);
    }
  }, [user?.id, supabase]);

  const getDisplayName = useCallback(() => {
    if (userProfile?.first_name) {
      return `${userProfile.first_name} ${userProfile.last_name || ''}`.trim();
    }
    return user?.email?.split('@')[0] || 'User';
  }, [userProfile, user]);

  const handleSignOut = useCallback(() => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            try {
              await signOut();
              navigation.reset({
                index: 0,
                routes: [{ name: 'Auth' }],
              });
            } catch (error) {
              Alert.alert('Error', 'Failed to sign out');
            }
          },
        },
      ]
    );
  }, [signOut, navigation]);

  const handleSaveProfile = useCallback(async () => {
    if (hapticFeedback) Vibration.vibrate(50);
    
    try {
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user?.id,
          first_name: editProfile.firstName,
          last_name: editProfile.lastName,
          phone: editProfile.phone,
          updated_at: new Date().toISOString(),
        });

      if (error) {
        Alert.alert('Error', 'Failed to update profile');
        return;
      }

      Alert.alert('Success', 'Profile updated successfully');
      setProfileModalVisible(false);
      
      // Refresh profile data
      await updateProfile();
    } catch (error) {
      Alert.alert('Error', 'Failed to update profile');
    }
  }, [editProfile, user?.id, supabase, updateProfile, hapticFeedback]);

  const handleExportData = useCallback(async () => {
    try {
      const { data: devices } = await supabase
        .from('appliances')
        .select('*')
        .eq('user_id', user?.id);

      const csvData = devices?.map(device => 
        `${device.name},${device.type},${device.room},${device.normal_usage},${device.status}`
      ).join('\n');

      const csvContent = `Name,Type,Room,Usage,Status\n${csvData}`;

      await Share.share({
        message: csvContent,
        title: 'Energy Monitor Data Export',
      });
    } catch (error) {
      Alert.alert('Error', 'Failed to export data');
    }
  }, [user?.id, supabase]);

  const handleDeleteAccount = useCallback(() => {
    Alert.alert(
      'Delete Account',
      'This action cannot be undone. All your data will be permanently deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete Account',
          style: 'destructive',
          onPress: () => {
            Alert.alert(
              'Final Confirmation',
              'Type "DELETE" to confirm account deletion',
              [
                { text: 'Cancel', style: 'cancel' },
                {
                  text: 'Confirm',
                  style: 'destructive',
                  onPress: async () => {
                    // In a real app, you'd implement account deletion here
                    Alert.alert('Info', 'Account deletion feature will be implemented');
                  },
                },
              ],
              { cancelable: true }
            );
          },
        },
      ]
    );
  }, []);

  const styles = createStyles(darkMode);

  const SettingItem = ({ icon, title, subtitle, onPress, rightElement, showBorder = true }) => (
    <TouchableOpacity 
      style={[styles.settingItem, !showBorder && styles.settingItemNoBorder]} 
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.settingItemLeft}>
        <Text style={styles.settingIcon}>{icon}</Text>
        <View style={styles.settingItemContent}>
          <Text style={styles.settingTitle}>{title}</Text>
          {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
        </View>
      </View>
      {rightElement}
    </TouchableOpacity>
  );

  const SettingSection = ({ title, children }) => (
    <View style={styles.settingSection}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.sectionContent}>
        {children}
      </View>
    </View>
  );

  return (
    <>
      <StatusBar 
        barStyle={darkMode ? "light-content" : "dark-content"} 
        backgroundColor={darkMode ? "#0a0a0b" : "#f8fafc"} 
      />
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <TouchableOpacity 
            style={styles.profileButton}
            onPress={() => setProfileModalVisible(true)}
            activeOpacity={0.8}
          >
            <View style={styles.profileAvatar}>
              <Text style={styles.profileAvatarText}>
                {getDisplayName().charAt(0).toUpperCase()}
              </Text>
            </View>
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>{getDisplayName()}</Text>
              <Text style={styles.profileEmail}>{user?.email}</Text>
              <Text style={styles.profileStatus}>Premium Member</Text>
            </View>
            <Text style={styles.profileArrow}>›</Text>
          </TouchableOpacity>
        </View>

        {/* Account Settings */}
        <SettingSection title="Account">
          <SettingItem
            icon="👤"
            title="Edit Profile"
            subtitle="Update your personal information"
            onPress={() => setProfileModalVisible(true)}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
          />
          <SettingItem
            icon="🔐"
            title="Change Password"
            subtitle="Update your account password"
            onPress={() => Alert.alert('Info', 'Password change feature coming soon')}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
          />
          <SettingItem
            icon="📧"
            title="Email Preferences"
            subtitle="Manage email notifications"
            onPress={() => Alert.alert('Info', 'Email preferences feature coming soon')}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
            showBorder={false}
          />
        </SettingSection>

        {/* App Preferences */}
        <SettingSection title="App Preferences">
          <SettingItem
            icon="🌙"
            title="Dark Mode"
            subtitle="Toggle dark theme"
            rightElement={
              <Switch
                value={darkMode}
                onValueChange={setDarkMode}
                trackColor={{ false: '#767577', true: '#10b981' }}
                thumbColor={darkMode ? '#f4f3f4' : '#f4f3f4'}
              />
            }
          />
          <SettingItem
            icon="🔔"
            title="Notifications"
            subtitle="Push notifications"
            rightElement={
              <Switch
                value={notifications}
                onValueChange={setNotifications}
                trackColor={{ false: '#767577', true: '#10b981' }}
                thumbColor={notifications ? '#f4f3f4' : '#f4f3f4'}
              />
            }
          />
          <SettingItem
            icon="📳"
            title="Haptic Feedback"
            subtitle="Vibration on interactions"
            rightElement={
              <Switch
                value={hapticFeedback}
                onValueChange={(value) => {
                  setHapticFeedback(value);
                  if (value) Vibration.vibrate(50);
                }}
                trackColor={{ false: '#767577', true: '#10b981' }}
                thumbColor={hapticFeedback ? '#f4f3f4' : '#f4f3f4'}
              />
            }
          />
          <SettingItem
            icon="🌍"
            title="Language"
            subtitle={language}
            onPress={() => Alert.alert('Info', 'Language selection feature coming soon')}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
            showBorder={false}
          />
        </SettingSection>

        {/* Energy Settings */}
        <SettingSection title="Energy Management">
          <SettingItem
            icon="⚡"
            title="Energy Alerts"
            subtitle={`Alert when usage exceeds ${energyThreshold}W`}
            rightElement={
              <Switch
                value={energyAlerts}
                onValueChange={setEnergyAlerts}
                trackColor={{ false: '#767577', true: '#10b981' }}
                thumbColor={energyAlerts ? '#f4f3f4' : '#f4f3f4'}
              />
            }
          />
          <SettingItem
            icon="🎯"
            title="Energy Threshold"
            subtitle={`Current: ${energyThreshold}W`}
            onPress={() => setEnergyModalVisible(true)}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
          />
          <SettingItem
            icon="🤖"
            title="Auto-Optimization"
            subtitle="Automatically optimize energy usage"
            rightElement={
              <Switch
                value={autoOptimization}
                onValueChange={setAutoOptimization}
                trackColor={{ false: '#767577', true: '#10b981' }}
                thumbColor={autoOptimization ? '#f4f3f4' : '#f4f3f4'}
              />
            }
          />
          <SettingItem
            icon="📊"
            title="Weekly Reports"
            subtitle="Receive energy usage reports"
            rightElement={
              <Switch
                value={weeklyReports}
                onValueChange={setWeeklyReports}
                trackColor={{ false: '#767577', true: '#10b981' }}
                thumbColor={weeklyReports ? '#f4f3f4' : '#f4f3f4'}
              />
            }
          />
          <SettingItem
            icon="💰"
            title="Currency"
            subtitle={currency}
            onPress={() => Alert.alert('Info', 'Currency selection feature coming soon')}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
            showBorder={false}
          />
        </SettingSection>

        {/* Data & Privacy */}
        <SettingSection title="Data & Privacy">
          <SettingItem
            icon="💾"
            title="Backup Data"
            subtitle={`Last backup: ${appStats.lastBackup}`}
            onPress={() => setBackupModalVisible(true)}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
          />
          <SettingItem
            icon="📤"
            title="Export Data"
            subtitle="Download your data"
            onPress={handleExportData}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
          />
          <SettingItem
            icon="🔒"
            title="Privacy Policy"
            subtitle="Read our privacy policy"
            onPress={() => Linking.openURL('https://example.com/privacy')}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
            showBorder={false}
          />
        </SettingSection>

        {/* Support & About */}
        <SettingSection title="Support & About">
          <SettingItem
            icon="❓"
            title="Help & FAQ"
            subtitle="Get help and find answers"
            onPress={() => Alert.alert('Info', 'Help center feature coming soon')}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
          />
          <SettingItem
            icon="📞"
            title="Contact Support"
            subtitle="Get in touch with our team"
            onPress={() => Linking.openURL('mailto:support@energymonitor.com')}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
          />
          <SettingItem
            icon="⭐"
            title="Rate App"
            subtitle="Rate us on the app store"
            onPress={() => Alert.alert('Thank you!', 'Rating feature coming soon')}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
          />
          <SettingItem
            icon="ℹ️"
            title="About"
            subtitle={`Version 1.0.0 • Data: ${appStats.dataUsage}`}
            onPress={() => setAboutModalVisible(true)}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
            showBorder={false}
          />
        </SettingSection>

        {/* Danger Zone */}
        <SettingSection title="Account Actions">
          <SettingItem
            icon="🚪"
            title="Sign Out"
            subtitle="Sign out of your account"
            onPress={handleSignOut}
            rightElement={<Text style={styles.settingArrow}>›</Text>}
          />
          <SettingItem
            icon="🗑️"
            title="Delete Account"
            subtitle="Permanently delete your account"
            onPress={handleDeleteAccount}
            rightElement={<Text style={[styles.settingArrow, { color: '#ef4444' }]}>›</Text>}
            showBorder={false}
          />
        </SettingSection>

        {/* Profile Edit Modal */}
        <Modal
          visible={profileModalVisible}
          animationType="slide"
          presentationStyle="pageSheet"
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setProfileModalVisible(false)}>
                <Text style={styles.modalButton}>Cancel</Text>
              </TouchableOpacity>
              <Text style={styles.modalTitle}>Edit Profile</Text>
              <TouchableOpacity onPress={handleSaveProfile}>
                <Text style={[styles.modalButton, styles.modalSaveButton]}>Save</Text>
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.modalContent}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>First Name</Text>
                <TextInput
                  style={styles.textInput}
                  value={editProfile.firstName}
                  onChangeText={(text) => setEditProfile(prev => ({ ...prev, firstName: text }))}
                  placeholder="Enter first name"
                  placeholderTextColor="#a1a1aa"
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Last Name</Text>
                <TextInput
                  style={styles.textInput}
                  value={editProfile.lastName}
                  onChangeText={(text) => setEditProfile(prev => ({ ...prev, lastName: text }))}
                  placeholder="Enter last name"
                  placeholderTextColor="#a1a1aa"
                />
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Email</Text>
                <TextInput
                  style={[styles.textInput, styles.textInputDisabled]}
                  value={editProfile.email}
                  editable={false}
                />
                <Text style={styles.inputHelper}>Email cannot be changed</Text>
              </View>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Phone Number</Text>
                <TextInput
                  style={styles.textInput}
                  value={editProfile.phone}
                  onChangeText={(text) => setEditProfile(prev => ({ ...prev, phone: text }))}
                  placeholder="Enter phone number"
                  placeholderTextColor="#a1a1aa"
                  keyboardType="phone-pad"
                />
              </View>
            </ScrollView>
          </View>
        </Modal>

        {/* Energy Threshold Modal */}
        <Modal
          visible={energyModalVisible}
          animationType="fade"
          transparent
        >
          <View style={styles.overlayModal}>
            <View style={styles.alertModal}>
              <Text style={styles.alertTitle}>Energy Threshold</Text>
              <Text style={styles.alertMessage}>
                Set the energy usage threshold for alerts (in Watts)
              </Text>
              
              <TextInput
                style={styles.alertInput}
                value={energyThreshold}
                onChangeText={setEnergyThreshold}
                keyboardType="numeric"
                placeholder="300"
                placeholderTextColor="#a1a1aa"
              />
              
              <View style={styles.alertButtons}>
                <TouchableOpacity 
                  style={[styles.alertButton, styles.alertButtonCancel]}
                  onPress={() => setEnergyModalVisible(false)}
                >
                  <Text style={styles.alertButtonTextCancel}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.alertButton, styles.alertButtonSave]}
                  onPress={() => {
                    setEnergyModalVisible(false);
                    if (hapticFeedback) Vibration.vibrate(50);
                    Alert.alert('Success', 'Energy threshold updated');
                  }}
                >
                  <Text style={styles.alertButtonText}>Save</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

        {/* About Modal */}
        <Modal
          visible={aboutModalVisible}
          animationType="fade"
          transparent
        >
          <View style={styles.overlayModal}>
            <View style={styles.aboutModal}>
              <Text style={styles.aboutTitle}>Energy Monitor</Text>
              <Text style={styles.aboutVersion}>Version 1.0.0</Text>
              
              <View style={styles.aboutStats}>
                <View style={styles.aboutStat}>
                  <Text style={styles.aboutStatValue}>{appStats.totalDevices}</Text>
                  <Text style={styles.aboutStatLabel}>Connected Devices</Text>
                </View>
                <View style={styles.aboutStat}>
                  <Text style={styles.aboutStatValue}>{appStats.dataUsage}</Text>
                  <Text style={styles.aboutStatLabel}>Data Usage</Text>
                </View>
                <View style={styles.aboutStat}>
                  <Text style={styles.aboutStatValue}>{appStats.memberSince}</Text>
                  <Text style={styles.aboutStatLabel}>Member Since</Text>
                </View>
              </View>
              
              <Text style={styles.aboutDescription}>
                Monitor and optimize your home's energy consumption with our smart energy management platform.
              </Text>
              
              <TouchableOpacity 
                style={styles.aboutCloseButton}
                onPress={() => setAboutModalVisible(false)}
              >
                <Text style={styles.aboutCloseText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* Backup Modal */}
        <Modal
          visible={backupModalVisible}
          animationType="fade"
          transparent
        >
          <View style={styles.overlayModal}>
            <View style={styles.alertModal}>
              <Text style={styles.alertTitle}>Backup Data</Text>
              <Text style={styles.alertMessage}>
                Create a backup of your devices and settings to the cloud.
              </Text>
              
              <View style={styles.backupInfo}>
                <Text style={styles.backupInfoText}>📱 {appStats.totalDevices} devices</Text>
                <Text style={styles.backupInfoText}>⚙️ App settings</Text>
                <Text style={styles.backupInfoText}>📊 Usage history</Text>
              </View>
              
              <View style={styles.alertButtons}>
                <TouchableOpacity 
                  style={[styles.alertButton, styles.alertButtonCancel]}
                  onPress={() => setBackupModalVisible(false)}
                >
                  <Text style={styles.alertButtonTextCancel}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.alertButton, styles.alertButtonSave]}
                  onPress={() => {
                    setBackupModalVisible(false);
                    Alert.alert('Success', 'Backup created successfully');
                  }}
                >
                  <Text style={styles.alertButtonText}>Create Backup</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

        <View style={styles.footerSpace} />
      </ScrollView>
    </>
  );
};

export default SettingsTab;