import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  Alert,
  Switch,
  Dimensions,
  Modal,
  TextInput,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { useAuth } from '../../Context/AuthContext';

const { width } = Dimensions.get('window');
const cardWidth = (width - 48) / 2;

export default function ControlsTab() {
  const { user, supabase } = useAuth();
  const [appliances, setAppliances] = useState([]);
  const [filteredAppliances, setFilteredAppliances] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingAppliance, setEditingAppliance] = useState(null);
  const [newAppliance, setNewAppliance] = useState({
    name: '',
    type: '',
    room: '',
    normal_usage: '',
  });
  const [stats, setStats] = useState({
    totalUsage: 0,
    monthlyCost: 0,
    activeDevices: 0,
    efficiency: 85,
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedAppliances, setSelectedAppliances] = useState([]);

  // Filter and sort appliances
  useEffect(() => {
    let result = [...appliances];
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(appliance => 
        appliance.name.toLowerCase().includes(query) ||
        appliance.room.toLowerCase().includes(query) ||
        appliance.type.toLowerCase().includes(query)
      );
    }
    
    // Apply sorting
    result.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'usage':
          return b.normal_usage - a.normal_usage;
        case 'room':
          return a.room.localeCompare(b.room);
        case 'status':
          return (b.status === 'on' ? 1 : 0) - (a.status === 'on' ? 1 : 0);
        default:
          return 0;
      }
    });
    
    setFilteredAppliances(result);
  }, [appliances, searchQuery, sortBy]);

  const getApplianceIcon = (type) => {
    const iconMap = {
      refrigerator: '❄️',
      tv: '📺',
      washing_machine: '🧺',
      air_conditioner: '💨',
      heater: '🔥',
      light: '💡',
      microwave: '🔥',
      dishwasher: '🍽️',
      computer: '💻',
      fan: '💨',
    };
    return iconMap[type.toLowerCase()] || '⚡';
  };

  const getEnergyLevel = (usage) => {
    if (usage <= 50) return { label: 'Excellent', color: '#10b981' };
    if (usage <= 100) return { label: 'Good', color: '#10b981' };
    if (usage <= 200) return { label: 'Normal', color: '#f59e0b' };
    if (usage <= 300) return { label: 'Warning', color: '#f97316' };
    return { label: 'High', color: '#ef4444' };
  };

  const toggleAppliance = async (applianceId, currentStatus) => {
    const newStatus = currentStatus === 'on' ? 'off' : 'on';
    
    try {
      const { error } = await supabase
        .from('appliances')
        .update({ status: newStatus })
        .eq('id', applianceId);

      if (error) {
        console.error('Error updating appliance:', error);
        Alert.alert('Error', 'Failed to update appliance status');
        return;
      }

      const updatedAppliances = appliances.map(app =>
        app.id === applianceId ? { ...app, status: newStatus } : app
      );
      setAppliances(updatedAppliances);
      calculateStats(updatedAppliances);
    } catch (error) {
      console.error('Error in toggleAppliance:', error);
      Alert.alert('Error', 'Failed to update appliance status');
    }
  };

  // Bulk toggle selected appliances
  const bulkToggleAppliances = async (status) => {
    if (selectedAppliances.length === 0) {
      Alert.alert('Info', 'Please select devices first');
      return;
    }

    try {
      const { error } = await supabase
        .from('appliances')
        .update({ status })
        .in('id', selectedAppliances);

      if (error) {
        console.error('Error bulk updating appliances:', error);
        Alert.alert('Error', 'Failed to update appliances');
        return;
      }

      const updatedAppliances = appliances.map(app =>
        selectedAppliances.includes(app.id) ? { ...app, status } : app
      );
      setAppliances(updatedAppliances);
      calculateStats(updatedAppliances);
      setSelectedAppliances([]);
      Alert.alert('Success', `${selectedAppliances.length} devices ${status}`);
    } catch (error) {
      console.error('Error in bulkToggleAppliances:', error);
      Alert.alert('Error', 'Failed to update appliances');
    }
  };

  // Toggle selection for an appliance
  const toggleApplianceSelection = (applianceId) => {
    setSelectedAppliances(prev => 
      prev.includes(applianceId) 
        ? prev.filter(id => id !== applianceId)
        : [...prev, applianceId]
    );
  };

  const calculateStats = (applianceList) => {
    const activeAppliances = applianceList.filter(app => app.status === 'on');
    const totalUsage = activeAppliances.reduce((sum, app) => sum + app.normal_usage, 0);

    const kWh = totalUsage / 1000;
    const hoursPerMonth = 24 * 30;
    const monthlyCost = kWh * hoursPerMonth * 2.50;

    const avgUsagePerDevice = totalUsage / Math.max(activeAppliances.length, 1);
    let efficiency = 100;
    if (avgUsagePerDevice > 300) efficiency = 60;
    else if (avgUsagePerDevice > 200) efficiency = 70;
    else if (avgUsagePerDevice > 100) efficiency = 80;
    else efficiency = 90;

    setStats({
      totalUsage: Math.round(totalUsage),
      monthlyCost: Math.round(monthlyCost),
      activeDevices: activeAppliances.length,
      efficiency,
    });
  };

  const fetchAppliances = useCallback(async () => {
    if (!user?.id) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('appliances')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching appliances:', error);
        Alert.alert('Error', 'Failed to load appliances');
        return;
      }

      setAppliances(data || []);
      calculateStats(data || []);
    } catch (error) {
      console.error('Error in fetchAppliances:', error);
      Alert.alert('Error', 'Failed to load appliances');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, supabase]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchAppliances();
  }, [fetchAppliances]);

  useEffect(() => {
    const loadData = async () => {
      await fetchAppliances();
    };
    
    if (user?.id) {
      loadData();
    }
  }, [user?.id, fetchAppliances]);

  const addAppliance = async () => {
    if (!newAppliance.name || !newAppliance.type || !newAppliance.room || !newAppliance.normal_usage) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('appliances')
        .insert([{
          user_id: user.id,
          name: newAppliance.name,
          type: newAppliance.type,
          room: newAppliance.room,
          normal_usage: parseInt(newAppliance.normal_usage),
          status: 'off',
        }])
        .select();

      if (error) {
        console.error('Error adding appliance:', error);
        Alert.alert('Error', 'Failed to add appliance');
        return;
      }

      setAppliances([...appliances, ...data]);
      calculateStats([...appliances, ...data]);
      setNewAppliance({ name: '', type: '', room: '', normal_usage: '' });
      setShowAddModal(false);
      Alert.alert('Success', 'Device added successfully!');
    } catch (error) {
      console.error('Error in addAppliance:', error);
      Alert.alert('Error', 'Failed to add appliance');
    }
  };

  const editAppliance = async () => {
    if (!editingAppliance) return;

    try {
      const { error } = await supabase
        .from('appliances')
        .update({
          name: editingAppliance.name,
          type: editingAppliance.type,
          room: editingAppliance.room,
          normal_usage: parseInt(editingAppliance.normal_usage),
        })
        .eq('id', editingAppliance.id);

      if (error) {
        console.error('Error updating appliance:', error);
        Alert.alert('Error', 'Failed to update appliance');
        return;
      }

      const updatedAppliances = appliances.map(app =>
        app.id === editingAppliance.id ? editingAppliance : app
      );
      setAppliances(updatedAppliances);
      calculateStats(updatedAppliances);
      setShowEditModal(false);
      setEditingAppliance(null);
      Alert.alert('Success', 'Device updated successfully!');
    } catch (error) {
      console.error('Error in editAppliance:', error);
      Alert.alert('Error', 'Failed to update appliance');
    }
  };

  const deleteAppliance = async (applianceId) => {
    Alert.alert(
      'Delete Device',
      'Are you sure you want to delete this device?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('appliances')
                .delete()
                .eq('id', applianceId);

              if (error) {
                console.error('Error deleting appliance:', error);
                Alert.alert('Error', 'Failed to delete appliance');
                return;
              }

              const updatedAppliances = appliances.filter(app => app.id !== applianceId);
              setAppliances(updatedAppliances);
              calculateStats(updatedAppliances);
              Alert.alert('Success', 'Device deleted successfully!');
            } catch (error) {
              console.error('Error in deleteAppliance:', error);
              Alert.alert('Error', 'Failed to delete appliance');
            }
          },
        },
      ]
    );
  };

  const openEditModal = (appliance) => {
    setEditingAppliance({ ...appliance });
    setShowEditModal(true);
  };

  const renderAddModal = () => (
    <Modal visible={showAddModal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowAddModal(false)}>
      <SafeAreaView style={styles.modalContainer}>
        <View style={styles.modalHeader}>
          <TouchableOpacity onPress={() => setShowAddModal(false)} activeOpacity={0.7}>
            <Text style={styles.modalCancel}>Cancel</Text>
          </TouchableOpacity>
          <Text style={styles.modalTitle}>Add New Device</Text>
          <TouchableOpacity onPress={addAppliance} activeOpacity={0.7}>
            <Text style={styles.modalSave}>Save</Text>
          </TouchableOpacity>
        </View>
        <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
          <View style={styles.modalForm}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Device Name *</Text>
              <TextInput style={styles.input} placeholder="e.g., Living Room TV" placeholderTextColor="#6b7280" value={newAppliance.name} onChangeText={(text) => setNewAppliance({...newAppliance, name: text})} />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Device Type *</Text>
              <View style={styles.typeSelector}>
                {['tv', 'refrigerator', 'light', 'air_conditioner', 'microwave', 'computer'].map((type) => (
                  <TouchableOpacity key={type} style={[styles.typeOption, newAppliance.type === type && styles.typeOptionActive]} onPress={() => setNewAppliance({...newAppliance, type})} activeOpacity={0.8}>
                    <Text style={styles.typeOptionIcon}>{getApplianceIcon(type)}</Text>
                    <Text style={[styles.typeOptionText, newAppliance.type === type && styles.typeOptionTextActive]}>
                      {type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Room *</Text>
              <TextInput style={styles.input} placeholder="e.g., Living Room, Kitchen" placeholderTextColor="#6b7280" value={newAppliance.room} onChangeText={(text) => setNewAppliance({...newAppliance, room: text})} />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Power Usage (Watts) *</Text>
              <TextInput style={styles.input} placeholder="e.g., 100" placeholderTextColor="#6b7280" keyboardType="numeric" value={newAppliance.normal_usage} onChangeText={(text) => setNewAppliance({...newAppliance, normal_usage: text})} />
              <Text style={styles.inputHint}>Typical usage values: Light (10-60W), TV (100-400W), Refrigerator (150-800W)</Text>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );

  const renderEditModal = () => (
    <Modal visible={showEditModal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowEditModal(false)}>
      <SafeAreaView style={styles.modalContainer}>
        <View style={styles.modalHeader}>
          <TouchableOpacity onPress={() => setShowEditModal(false)} activeOpacity={0.7}>
            <Text style={styles.modalCancel}>Cancel</Text>
          </TouchableOpacity>
          <Text style={styles.modalTitle}>Edit Device</Text>
          <TouchableOpacity onPress={editAppliance} activeOpacity={0.7}>
            <Text style={styles.modalSave}>Save</Text>
          </TouchableOpacity>
        </View>
        <ScrollView style={styles.modalContent} showsVerticalScrollIndicator={false}>
          <View style={styles.modalForm}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Device Name *</Text>
              <TextInput style={styles.input} placeholder="e.g., Living Room TV" placeholderTextColor="#6b7280" value={editingAppliance?.name || ''} onChangeText={(text) => setEditingAppliance({...editingAppliance, name: text})} />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Device Type *</Text>
              <View style={styles.typeSelector}>
                {['tv', 'refrigerator', 'light', 'air_conditioner', 'microwave', 'computer'].map((type) => (
                  <TouchableOpacity key={type} style={[styles.typeOption, editingAppliance?.type === type && styles.typeOptionActive]} onPress={() => setEditingAppliance({...editingAppliance, type})} activeOpacity={0.8}>
                    <Text style={styles.typeOptionIcon}>{getApplianceIcon(type)}</Text>
                    <Text style={[styles.typeOptionText, editingAppliance?.type === type && styles.typeOptionTextActive]}>
                      {type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Room *</Text>
              <TextInput style={styles.input} placeholder="e.g., Living Room, Kitchen" placeholderTextColor="#6b7280" value={editingAppliance?.room || ''} onChangeText={(text) => setEditingAppliance({...editingAppliance, room: text})} />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Power Usage (Watts) *</Text>
              <TextInput style={styles.input} placeholder="e.g., 100" placeholderTextColor="#6b7280" keyboardType="numeric" value={editingAppliance?.normal_usage?.toString() || ''} onChangeText={(text) => setEditingAppliance({...editingAppliance, normal_usage: text})} />
              <Text style={styles.inputHint}>Typical usage values: Light (10-60W), TV (100-400W), Refrigerator (150-800W)</Text>
            </View>
            <TouchableOpacity 
              style={styles.deleteButton}
              onPress={() => deleteAppliance(editingAppliance?.id)}
            >
              <Text style={styles.deleteButtonText}>Delete Device</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );

  const renderStatsCard = () => (
    <View style={styles.statsContainer}>
      <View style={styles.statCard}>
        <Text style={styles.statValue}>{stats.totalUsage}W</Text>
        <Text style={styles.statLabel}>Current Usage</Text>
      </View>
      <View style={styles.statCard}>
        <Text style={styles.statValue}>R{stats.monthlyCost}</Text>
        <Text style={styles.statLabel}>Monthly Cost</Text>
      </View>
      <View style={styles.statCard}>
        <Text style={styles.statValue}>{stats.activeDevices}</Text>
        <Text style={styles.statLabel}>Active Devices</Text>
      </View>
      <View style={styles.statCard}>
        <Text style={styles.statValue}>{stats.efficiency}%</Text>
        <Text style={styles.statLabel}>Efficiency</Text>
      </View>
    </View>
  );

  if (loading && appliances.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#10b981" />
          <Text style={styles.loadingText}>Loading devices...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <View style={styles.controlsHeader}>
          <Text style={styles.pageTitle}>Device Controls</Text>
          <TouchableOpacity 
            style={styles.addButton}
            onPress={() => setShowAddModal(true)}
            activeOpacity={0.8}
          >
            <Text style={styles.addButtonText}>+ Add Device</Text>
          </TouchableOpacity>
        </View>

        {renderStatsCard()}

        {/* Search and Filter Section */}
        <View style={styles.filterSection}>
          <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              placeholder="Search devices..."
              placeholderTextColor="#6b7280"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
          <View style={styles.sortContainer}>
            <Text style={styles.sortLabel}>Sort by:</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {[
                { key: 'name', label: 'Name' },
                { key: 'usage', label: 'Usage' },
                { key: 'room', label: 'Room' },
                { key: 'status', label: 'Status' }
              ].map((item) => (
                <TouchableOpacity
                  key={item.key}
                  style={[styles.sortOption, sortBy === item.key && styles.sortOptionActive]}
                  onPress={() => setSortBy(item.key)}
                >
                  <Text style={[styles.sortOptionText, sortBy === item.key && styles.sortOptionTextActive]}>
                    {item.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>

        {/* Bulk Actions */}
        {selectedAppliances.length > 0 && (
          <View style={styles.bulkActions}>
            <Text style={styles.bulkText}>{selectedAppliances.length} selected</Text>
            <View style={styles.bulkButtons}>
              <TouchableOpacity 
                style={styles.bulkButton}
                onPress={() => bulkToggleAppliances('on')}
              >
                <Text style={styles.bulkButtonText}>Turn On</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.bulkButton, styles.bulkButtonOff]}
                onPress={() => bulkToggleAppliances('off')}
              >
                <Text style={styles.bulkButtonText}>Turn Off</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.bulkCancel}
                onPress={() => setSelectedAppliances([])}
              >
                <Text style={styles.bulkCancelText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {filteredAppliances.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>🔍</Text>
            <Text style={styles.emptyTitle}>
              {searchQuery ? 'No devices found' : 'No Devices Added'}
            </Text>
            <Text style={styles.emptySubtitle}>
              {searchQuery ? 'Try adjusting your search terms' : 'Add your first smart home device to get started'}
            </Text>
            {!searchQuery && (
              <TouchableOpacity 
                style={styles.emptyButton}
                onPress={() => setShowAddModal(true)}
                activeOpacity={0.8}
              >
                <Text style={styles.emptyButtonText}>Add First Device</Text>
              </TouchableOpacity>
            )}
          </View>
        ) : (
          <View style={styles.deviceGrid}>
            {filteredAppliances.map((item) => {
              const energyLevel = getEnergyLevel(item.normal_usage);
              const monthlyCost = Math.round((item.normal_usage / 1000) * 24 * 30 * 2.50);
              const isSelected = selectedAppliances.includes(item.id);

              return (
                <TouchableOpacity 
                  key={item.id} 
                  style={[styles.deviceCard, isSelected && styles.deviceCardSelected]}
                  onPress={() => toggleApplianceSelection(item.id)}
                  onLongPress={() => openEditModal(item)}
                  activeOpacity={0.9}
                >
                  <View style={styles.deviceHeader}>
                    <Text style={styles.deviceCardIcon}>{getApplianceIcon(item.type)}</Text>
                    <Switch
                      value={item.status === 'on'}
                      onValueChange={() => toggleAppliance(item.id, item.status)}
                      trackColor={{ false: 'rgba(255, 255, 255, 0.2)', true: '#10b981' }}
                      thumbColor="#ffffff"
                    />
                  </View>
                  <Text style={styles.deviceCardName}>{item.name}</Text>
                  <Text style={styles.deviceCardRoom}>{item.room}</Text>
                  <View style={styles.deviceCardStats}>
                    <Text style={styles.deviceCardUsage}>{item.normal_usage}W</Text>
                    <Text style={styles.deviceCardCost}>R{monthlyCost}/mo</Text>
                  </View>
                  <View style={[styles.deviceCardBadge, { backgroundColor: energyLevel.color }]}>
                    <Text style={styles.deviceCardBadgeText}>{energyLevel.label}</Text>
                  </View>
                  {isSelected && (
                    <View style={styles.selectedOverlay}>
                      <Text style={styles.selectedCheck}>✓</Text>
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </ScrollView>
      {renderAddModal()}
      {renderEditModal()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0b',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#ffffff',
    marginTop: 16,
    fontSize: 16,
  },
  // Controls Header
  controlsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 24,
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#ffffff',
  },
  addButton: {
    backgroundColor: '#10b981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 14,
  },
  // Stats Container
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: (width - 56) / 2,
    backgroundColor: '#18181b',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#10b981',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#a1a1aa',
  },
  // Filter Section
  filterSection: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  searchContainer: {
    marginBottom: 12,
  },
  searchInput: {
    backgroundColor: '#18181b',
    color: '#ffffff',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#27272a',
  },
  sortContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  sortLabel: {
    color: '#a1a1aa',
    marginRight: 12,
    fontSize: 14,
  },
  sortOption: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8,
    backgroundColor: '#18181b',
  },
  sortOptionActive: {
    backgroundColor: '#10b981',
  },
  sortOptionText: {
    color: '#a1a1aa',
    fontSize: 12,
    fontWeight: '600',
  },
  sortOptionTextActive: {
    color: '#ffffff',
  },
  // Bulk Actions
  bulkActions: {
    backgroundColor: '#1e40af',
    marginHorizontal: 16,
    marginBottom: 16,
    padding: 16,
    borderRadius: 12,
  },
  bulkText: {
    color: '#ffffff',
    fontWeight: '600',
    marginBottom: 12,
  },
  bulkButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  bulkButton: {
    backgroundColor: '#10b981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  bulkButtonOff: {
    backgroundColor: '#ef4444',
  },
  bulkButtonText: {
    color: '#ffffff',
    fontWeight: '600',
    fontSize: 14,
  },
  bulkCancel: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  bulkCancelText: {
    color: '#ffffff',
    fontWeight: '600',
    fontSize: 14,
  },
  // Device Grid
  deviceGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    gap: 16,
    marginBottom: 24,
  },
  deviceCard: {
    width: cardWidth,
    backgroundColor: '#18181b',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#27272a',
  },
  deviceCardSelected: {
    borderColor: '#10b981',
    borderWidth: 2,
  },
  deviceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  deviceCardIcon: {
    fontSize: 28,
  },
  deviceCardName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 4,
  },
  deviceCardRoom: {
    fontSize: 12,
    color: '#a1a1aa',
    marginBottom: 8,
  },
  deviceCardStats: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  deviceCardUsage: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  deviceCardCost: {
    fontSize: 14,
    color: '#a1a1aa',
  },
  deviceCardBadge: {
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    alignSelf: 'flex-start',
  },
  deviceCardBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
  },
  selectedOverlay: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#10b981',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheck: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  // Empty State
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
    minHeight: 300,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#a1a1aa',
    textAlign: 'center',
    marginBottom: 24,
  },
  emptyButton: {
    backgroundColor: '#10b981',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
  },
  emptyButtonText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 16,
  },
  // Add Device Modal
  modalContainer: {
    flex: 1,
    backgroundColor: '#0a0a0b',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1f2937',
  },
  modalCancel: {
    fontSize: 16,
    color: '#ef4444',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffffff',
  },
  modalSave: {
    fontSize: 16,
    color: '#10b981',
    fontWeight: '600',
  },
  modalContent: {
    padding: 24,
  },
  modalForm: {
    gap: 24,
  },
  inputGroup: {
    gap: 8,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
  },
  input: {
    backgroundColor: '#18181b',
    color: '#ffffff',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#27272a',
  },
  inputHint: {
    fontSize: 12,
    color: '#a1a1aa',
    marginTop: 4,
  },
  typeSelector: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  typeOption: {
    flexDirection: 'column',
    alignItems: 'center',
    backgroundColor: '#1f2937',
    padding: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  typeOptionActive: {
    backgroundColor: '#10b981',
    borderColor: '#10b981',
  },
  typeOptionIcon: {
    fontSize: 28,
  },
  typeOptionText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#a1a1aa',
    marginTop: 4,
  },
  typeOptionTextActive: {
    color: '#ffffff',
  },
  deleteButton: {
    backgroundColor: '#ef4444',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 24,
  },
  deleteButtonText: {
    color: '#ffffff',
    fontWeight: '600',
    fontSize: 16,
  },
});