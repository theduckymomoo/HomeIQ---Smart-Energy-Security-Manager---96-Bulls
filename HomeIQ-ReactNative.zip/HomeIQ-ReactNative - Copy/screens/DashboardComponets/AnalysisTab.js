// AnalysisTab.js

import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Animated,
  Easing,
  RefreshControl,
  Alert,
  Modal,
  Vibration,
} from 'react-native';
import { useAuth } from '../../Context/AuthContext';
import styles from './styles/AnalysisStyles'; // Import the new styles file

export default function AnalysisTab({ appliances = [], stats = {} }) {
  const { user, supabase } = useAuth();
  const [refreshing, setRefreshing] = useState(false);
  const [selectedTimeFrame, setSelectedTimeFrame] = useState('week');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [insights, setInsights] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState(null);
  const [expandedSection, setExpandedSection] = useState(null);
  
  // Animation values
  const [fadeAnim] = useState(new Animated.Value(0));
  const [slideAnim] = useState(new Animated.Value(50));
  const [scaleAnim] = useState(new Animated.Value(0.8));
  const [pulseAnim] = useState(new Animated.Value(1));

  const timeFrames = [
    { id: 'day', label: 'Today', icon: '🌞' },
    { id: 'week', label: 'Week', icon: '📅' },
    { id: 'month', label: 'Month', icon: '📊' },
    { id: 'year', label: 'Year', icon: '📈' },
  ];

  const categories = [
    { id: 'all', label: 'All', icon: '🔌' },
    { id: 'light', label: 'Lights', icon: '💡' },
    { id: 'air_conditioner', label: 'AC', icon: '❄️' },
    { id: 'tv', label: 'Entertainment', icon: '📺' },
    { id: 'appliance', label: 'Appliances', icon: '⚡' },
  ];

  // Pulsing animation for important elements
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  // Animate on mount
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        easing: Easing.out(Easing.back(1)),
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 700,
        easing: Easing.elastic(1),
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const getApplianceIcon = (type) => {
    const iconMap = {
      refrigerator: '❄️',
      tv: '📺',
      washing_machine: '🧺',
      air_conditioner: '💨',
      heater: '🔥',
      light: '💡',
      microwave: '🔥',
      dishwasher: '🍽️',
      computer: '💻',
      fan: '💨',
    };
    return iconMap[type.toLowerCase()] || '⚡';
  };

  const generateInsights = useCallback(() => {
    if (!appliances || appliances.length === 0) return [];

    const activeAppliances = appliances.filter(app => app.status === 'on');
    const highUsageDevices = appliances.filter(app => app.normal_usage > 200);
    
    const newInsights = [
      {
        id: 1,
        type: 'warning',
        icon: '⚡',
        title: 'High Usage Alert',
        description: `${highUsageDevices.length} devices using more than 200W`,
        action: 'Optimize now',
        impact: `Save R${Math.round(stats.monthlyCost * 0.2)}/month`,
        color: '#ef4444',
        details: 'These devices are consuming significant energy. Consider using them during off-peak hours or replacing with energy-efficient models.',
        devices: highUsageDevices.map(d => d.name),
      },
      {
        id: 2,
        type: 'tip',
        icon: '💡',
        title: 'Efficiency Tip',
        description: 'Turn off standby devices during peak hours',
        action: 'Set schedule',
        impact: 'Reduce usage by 15%',
        color: '#10b981',
        details: 'Devices on standby can account for up to 10% of your energy bill. Schedule them to turn off automatically.',
        devices: appliances.filter(d => d.status === 'standby').map(d => d.name),
      },
      {
        id: 3,
        type: 'achievement',
        icon: '🏆',
        title: 'Great Job!',
        description: `You're using ${activeAppliances.length} devices efficiently`,
        action: 'View details',
        impact: 'Better than 75% of users',
        color: '#f59e0b',
        details: 'Your energy efficiency is excellent! Keep up the good habits to maintain these savings.',
        devices: activeAppliances.map(d => d.name),
      },
    ];

    return newInsights;
  }, [appliances, stats]);

  const calculateAnalytics = useCallback(() => {
    if (!appliances || appliances.length === 0) {
      return {
        totalAppliances: 0,
        activeAppliances: 0,
        categoryUsage: [],
        roomUsage: [],
        peakHours: [],
        monthlyProjection: 0,
        carbonFootprint: 0,
        efficiencyScore: 0,
      };
    }

    const totalAppliances = appliances.length;
    const activeAppliances = appliances.filter(app => app.status === 'on');
    const inactiveAppliances = appliances.filter(app => app.status === 'off');

    const categoryUsage = {};
    const roomUsage = {};

    appliances.forEach(app => {
      const usage = app.status === 'on' ? app.normal_usage : 0;

      if (!categoryUsage[app.type]) {
        categoryUsage[app.type] = { usage: 0, count: 0, devices: [] };
      }
      categoryUsage[app.type].usage += usage;
      categoryUsage[app.type].count += 1;
      categoryUsage[app.type].devices.push(app);

      if (!roomUsage[app.room]) {
        roomUsage[app.room] = { usage: 0, count: 0, devices: [] };
      }
      roomUsage[app.room].usage += usage;
      roomUsage[app.room].count += 1;
      roomUsage[app.room].devices.push(app);
    });

    const sortedCategories = Object.entries(categoryUsage)
      .sort(([,a], [,b]) => b.usage - a.usage)
      .slice(0, 5);

    const sortedRooms = Object.entries(roomUsage)
      .sort(([,a], [,b]) => b.usage - a.usage)
      .slice(0, 4);

    const peakHours = [
      { time: '7-9 AM', usage: stats.totalUsage * 0.8, category: 'Morning' },
      { time: '12-2 PM', usage: stats.totalUsage * 0.6, category: 'Lunch' },
      { time: '6-8 PM', usage: stats.totalUsage * 1.2, category: 'Evening' },
      { time: '9-11 PM', usage: stats.totalUsage * 0.9, category: 'Night' },
    ];

    const monthlyProjection = Math.round(stats.monthlyCost * 1.15);
    const carbonFootprint = Math.round((stats.totalUsage / 1000) * 24 * 30 * 0.5);
    const efficiencyScore = Math.round((activeAppliances.length / Math.max(totalAppliances, 1)) * (stats.efficiency || 85));

    return {
      totalAppliances,
      activeAppliances: activeAppliances.length,
      inactiveAppliances: inactiveAppliances.length,
      categoryUsage: sortedCategories,
      roomUsage: sortedRooms,
      peakHours,
      monthlyProjection,
      carbonFootprint,
      efficiencyScore,
      allAppliances: appliances,
    };
  }, [appliances, stats]);

  const analytics = calculateAnalytics();
  const generatedInsights = generateInsights();

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    Vibration.vibrate(50);
    // Simulate refresh delay
    setTimeout(() => {
      setRefreshing(false);
      // Show refresh confirmation
      Alert.alert('✅ Data Updated', 'Your analytics have been refreshed with the latest data.');
    }, 1000);
  }, []);

  const showModal = (content) => {
    Vibration.vibrate(30);
    setModalContent(content);
    setModalVisible(true);
  };

  const handleInsightPress = (insight) => {
    Vibration.vibrate(30);
    
    Alert.alert(
      insight.title,
      `${insight.description}\n\n${insight.impact}`,
      [
        { text: 'Later', style: 'cancel' },
        { text: 'View Details', onPress: () => showModal({
          type: 'insight',
          title: insight.title,
          content: insight,
        })},
        { text: insight.action, onPress: () => {
          // Handle insight action
          Alert.alert('Action Taken', `Applied: ${insight.title}`);
          Vibration.vibrate(100);
        }},
      ]
    );
  };

  const handleTimeFramePress = (timeFrame) => {
    Vibration.vibrate(10);
    setSelectedTimeFrame(timeFrame);
    
    // Add haptic feedback and animation
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const handleCategoryPress = (category) => {
    Vibration.vibrate(10);
    setSelectedCategory(category);
    
    // Show category details in modal
    if (category !== 'all') {
      const categoryData = analytics.categoryUsage.find(([cat]) => cat === category);
      if (categoryData) {
        showModal({
          type: 'category',
          title: `${category.replace('_', ' ').toUpperCase()} Details`,
          content: categoryData,
        });
      }
    }
  };

  const handleRoomPress = (roomData) => {
    Vibration.vibrate(10);
    showModal({
      type: 'room',
      title: `${roomData[0]} Energy Usage`,
      content: roomData,
    });
  };

  const handleStatCardPress = (type) => {
    Vibration.vibrate(10);
    let content = {};
    
    switch (type) {
      case 'usage':
        content = {
          type: 'stat',
          title: 'Current Usage Details',
          content: {
            description: 'Real-time power consumption across all devices',
            devices: analytics.allAppliances.filter(app => app.status === 'on'),
            total: stats.totalUsage,
          }
        };
        break;
      case 'cost':
        content = {
          type: 'stat',
          title: 'Cost Analysis',
          content: {
            description: 'Monthly expenditure breakdown',
            current: stats.monthlyCost,
            projection: analytics.monthlyProjection,
            savings: Math.round(stats.monthlyCost * 0.08),
          }
        };
        break;
      case 'carbon':
        content = {
          type: 'stat',
          title: 'Environmental Impact',
          content: {
            description: 'Your carbon footprint reduction',
            saved: analytics.carbonFootprint,
            equivalent: `${Math.round(analytics.carbonFootprint / 20)} trees planted`,
          }
        };
        break;
      case 'efficiency':
        content = {
          type: 'stat',
          title: 'Efficiency Score',
          content: {
            description: 'How you compare to optimal usage',
            score: analytics.efficiencyScore,
            tips: ['Turn off unused devices', 'Use energy-efficient modes', 'Schedule high-usage appliances'],
          }
        };
        break;
    }
    
    showModal(content);
  };

  const toggleSection = (section) => {
    Vibration.vibrate(10);
    setExpandedSection(expandedSection === section ? null : section);
  };

  const renderPeakUsageBar = (peak, index, maxUsage) => {
    const barHeight = (peak.usage / maxUsage) * 80;
    const colors = ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
    
    return (
      <TouchableOpacity 
        key={index} 
        style={styles.peakBarContainer} 
        activeOpacity={0.7}
        onPress={() => showModal({
          type: 'peak',
          title: `${peak.time} Usage`,
          content: peak,
        })}
      >
        <View style={styles.peakBarWrapper}>
          <Animated.View
            style={[
              styles.peakBar,
              { 
                height: barHeight,
                backgroundColor: colors[index % colors.length],
              }
            ]}
          />
        </View>
        <Text style={styles.peakTime}>{peak.time}</Text>
        <Text style={styles.peakUsage}>{Math.round(peak.usage)}W</Text>
      </TouchableOpacity>
    );
  };

  const renderCategoryItem = ([category, data], index) => {
    const percentage = Math.round((data.usage / Math.max(stats.totalUsage, 1)) * 100);
    const colors = ['#10b981', '#f59e0b', '#8b5cf6', '#06b6d4', '#f97316'];
    const isSelected = selectedCategory === category;
    
    return (
      <Animated.View
        key={category}
        style={[
          styles.categoryCard,
          {
            opacity: fadeAnim,
            transform: [
              { translateY: slideAnim },
              { scale: isSelected ? 1.02 : scaleAnim },
            ],
            borderColor: isSelected ? colors[index % colors.length] : 'rgba(255, 255, 255, 0.1)',
          },
        ]}
      >
        <TouchableOpacity 
          activeOpacity={0.7} 
          onPress={() => handleCategoryPress(category)}
          onLongPress={() => {
            Vibration.vibrate(50);
            Alert.alert(
              `${category.replace('_', ' ').toUpperCase()}`, 
              `Total usage: ${data.usage}W\nDevices: ${data.count}`
            );
          }}
        >
          <View style={styles.categoryHeader}>
            <View style={styles.categoryInfo}>
              <Text style={styles.categoryIcon}>{getApplianceIcon(category)}</Text>
              <View style={styles.categoryText}>
                <Text style={styles.categoryName}>
                  {category.replace('_', ' ').toUpperCase()}
                </Text>
                <Text style={styles.categoryStats}>
                  {data.count} devices • {data.usage}W
                </Text>
              </View>
            </View>
            <View style={[styles.percentageBadge, { backgroundColor: colors[index % colors.length] + '20' }]}>
              <Text style={[styles.percentageText, { color: colors[index % colors.length] }]}>
                {percentage}%
              </Text>
            </View>
          </View>
          
          <View style={styles.progressContainer}>
            <View style={styles.progressBackground}>
              <View
                style={[
                  styles.progressFill,
                  { 
                    width: `${percentage}%`,
                    backgroundColor: colors[index % colors.length],
                  }
                ]}
              />
            </View>
            <View style={styles.progressLabels}>
              <Text style={styles.progressLabel}>0W</Text>
              <Text style={styles.progressLabel}>{stats.totalUsage}W</Text>
            </View>
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  const renderModalContent = () => {
    if (!modalContent) return null;

    switch (modalContent.type) {
      case 'insight':
        return (
          <View>
            <Text style={styles.modalTitle}>{modalContent.title}</Text>
            <Text style={styles.modalDescription}>{modalContent.content.details}</Text>
            {modalContent.content.devices && modalContent.content.devices.length > 0 && (
              <View style={styles.modalSection}>
                <Text style={styles.modalSectionTitle}>Affected Devices:</Text>
                {modalContent.content.devices.map((device, index) => (
                  <Text key={index} style={styles.modalListItem}>• {device}</Text>
                ))}
              </View>
            )}
          </View>
        );
      
      case 'category':
        return (
          <View>
            <Text style={styles.modalTitle}>{modalContent.title}</Text>
            <View style={styles.modalStats}>
              <View style={styles.modalStat}>
                <Text style={styles.modalStatValue}>{modalContent.content[1].usage}W</Text>
                <Text style={styles.modalStatLabel}>Total Usage</Text>
              </View>
              <View style={styles.modalStat}>
                <Text style={styles.modalStatValue}>{modalContent.content[1].count}</Text>
                <Text style={styles.modalStatLabel}>Devices</Text>
              </View>
            </View>
            <View style={styles.modalSection}>
              <Text style={styles.modalSectionTitle}>Devices in this category:</Text>
              {modalContent.content[1].devices.map((device, index) => (
                <View key={index} style={styles.modalDeviceItem}>
                  <Text style={styles.modalDeviceName}>• {device.name}</Text>
                  <Text style={styles.modalDeviceUsage}>{device.normal_usage}W • {device.status}</Text>
                </View>
              ))}
            </View>
          </View>
        );
      
      default:
        return (
          <View>
            <Text style={styles.modalTitle}>{modalContent.title}</Text>
            <Text style={styles.modalDescription}>Detailed information here...</Text>
          </View>
        );
    }
  };

  if (!appliances || appliances.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView 
          contentContainerStyle={styles.emptyContainer}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#10b981']} />
          }
        >
          <Animated.Text style={[styles.emptyIcon, { transform: [{ scale: pulseAnim }] }]}>
            📊
          </Animated.Text>
          <Text style={styles.emptyTitle}>No Data Available</Text>
          <Text style={styles.emptySubtitle}>
            Connect some devices to see detailed analytics
          </Text>
          <TouchableOpacity 
            style={styles.emptyButton} 
            activeOpacity={0.7}
            onPress={() => Vibration.vibrate(30)}
          >
            <Text style={styles.emptyButtonText}>Add Devices</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#10b981']} />
        }
      >
        {/* Header */}
        <Animated.View 
          style={[
            styles.header,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View>
            <Text style={styles.title}>Energy Analytics</Text>
            <Text style={styles.subtitle}>Smart insights for your home</Text>
          </View>
          <TouchableOpacity 
            style={styles.efficiencyBadge}
            onPress={() => handleStatCardPress('efficiency')}
            activeOpacity={0.7}
          >
            <Text style={styles.efficiencyScore}>{analytics.efficiencyScore}%</Text>
            <Text style={styles.efficiencyLabel}>Efficiency</Text>
          </TouchableOpacity>
        </Animated.View>

        {/* Time Frame Selector */}
        <Animated.View 
          style={[
            styles.timeFrameContainer,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {timeFrames.map((frame) => (
              <TouchableOpacity
                key={frame.id}
                style={[
                  styles.timeFrameButton,
                  selectedTimeFrame === frame.id && styles.timeFrameButtonActive,
                ]}
                onPress={() => handleTimeFramePress(frame.id)}
                activeOpacity={0.7}
              >
                <Text style={[
                  styles.timeFrameIcon,
                  selectedTimeFrame === frame.id && styles.timeFrameIconActive,
                ]}>
                  {frame.icon}
                </Text>
                <Text style={[
                  styles.timeFrameText,
                  selectedTimeFrame === frame.id && styles.timeFrameTextActive,
                ]}>
                  {frame.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </Animated.View>

        {/* Quick Stats */}
        <Animated.View 
          style={[
            styles.statsGrid,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <TouchableOpacity 
            style={styles.statCard} 
            activeOpacity={0.8}
            onPress={() => handleStatCardPress('usage')}
          >
            <Text style={styles.statIcon}>⚡</Text>
            <Text style={styles.statValue}>{stats.totalUsage}W</Text>
            <Text style={styles.statLabel}>Current Usage</Text>
            <View style={styles.statTrend}>
              <Text style={styles.statTrendText}>Live</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.statCard} 
            activeOpacity={0.8}
            onPress={() => handleStatCardPress('cost')}
          >
            <Text style={styles.statIcon}>💰</Text>
            <Text style={styles.statValue}>R{stats.monthlyCost}</Text>
            <Text style={styles.statLabel}>Monthly Cost</Text>
            <View style={styles.statTrend}>
              <Text style={[styles.statTrendText, { color: '#10b981' }]}>-8% ↘️</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.statCard} 
            activeOpacity={0.8}
            onPress={() => handleStatCardPress('carbon')}
          >
            <Text style={styles.statIcon}>🌱</Text>
            <Text style={styles.statValue}>{analytics.carbonFootprint}kg</Text>
            <Text style={styles.statLabel}>CO₂ Saved</Text>
            <View style={styles.statTrend}>
              <Text style={styles.statTrendText}>This month</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.statCard} 
            activeOpacity={0.8}
            onPress={() => handleStatCardPress('efficiency')}
          >
            <Text style={styles.statIcon}>🏆</Text>
            <Text style={styles.statValue}>{analytics.efficiencyScore}%</Text>
            <Text style={styles.statLabel}>Efficiency</Text>
            <View style={styles.statTrend}>
              <Text style={[styles.statTrendText, { color: '#10b981' }]}>+12% ↗️</Text>
            </View>
          </TouchableOpacity>
        </Animated.View>

        {/* Smart Insights */}
        <TouchableOpacity 
          activeOpacity={0.7}
          onPress={() => toggleSection('insights')}
          style={styles.sectionHeaderButton}
        >
          <Animated.View 
            style={[
              styles.section,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            <View style={styles.sectionHeader}>
              <View>
                <Text style={styles.sectionTitle}>🤖 Smart Insights</Text>
                <Text style={styles.sectionSubtitle}>AI-powered recommendations</Text>
              </View>
              <Text style={styles.expandIcon}>{expandedSection === 'insights' ? '▼' : '▶'}</Text>
            </View>
          </Animated.View>
        </TouchableOpacity>

        {expandedSection === 'insights' && (
          <Animated.View 
            style={[
              styles.sectionContent,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.insightsScroll}>
              {generatedInsights.map((insight, index) => (
                <TouchableOpacity
                  key={insight.id}
                  style={[styles.insightCard, { borderLeftColor: insight.color }]}
                  onPress={() => handleInsightPress(insight)}
                  activeOpacity={0.7}
                >
                  <View style={styles.insightHeader}>
                    <Text style={styles.insightIcon}>{insight.icon}</Text>
                    <View style={[styles.insightBadge, { backgroundColor: insight.color }]}>
                      <Text style={styles.insightBadgeText}>{insight.type}</Text>
                    </View>
                  </View>
                  <Text style={styles.insightTitle}>{insight.title}</Text>
                  <Text style={styles.insightDescription}>{insight.description}</Text>
                  <View style={styles.insightFooter}>
                    <Text style={styles.insightImpact}>{insight.impact}</Text>
                    <Text style={styles.insightAction}>{insight.action} →</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </Animated.View>
        )}

        {/* Peak Usage */}
        <TouchableOpacity 
          activeOpacity={0.7}
          onPress={() => toggleSection('peak')}
          style={styles.sectionHeaderButton}
        >
          <Animated.View 
            style={[
              styles.section,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            <View style={styles.sectionHeader}>
              <View>
                <Text style={styles.sectionTitle}>📈 Peak Usage</Text>
                <Text style={styles.sectionSubtitle}>Daily energy patterns</Text>
              </View>
              <Text style={styles.expandIcon}>{expandedSection === 'peak' ? '▼' : '▶'}</Text>
            </View>
          </Animated.View>
        </TouchableOpacity>

        {expandedSection === 'peak' && (
          <Animated.View 
            style={[
              styles.sectionContent,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            <View style={styles.peakUsageContainer}>
              <View style={styles.peakBars}>
                {analytics.peakHours.map((peak, index) => 
                  renderPeakUsageBar(peak, index, Math.max(...analytics.peakHours.map(p => p.usage)))
                )}
              </View>
            </View>
          </Animated.View>
        )}

        {/* Category Breakdown */}
        <TouchableOpacity 
          activeOpacity={0.7}
          onPress={() => toggleSection('category')}
          style={styles.sectionHeaderButton}
        >
          <Animated.View 
            style={[
              styles.section,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            <View style={styles.sectionHeader}>
              <View>
                <Text style={styles.sectionTitle}>🏷️ Category Breakdown</Text>
                <Text style={styles.sectionSubtitle}>Usage by device type</Text>
              </View>
              <Text style={styles.expandIcon}>{expandedSection === 'category' ? '▼' : '▶'}</Text>
            </View>
          </Animated.View>
        </TouchableOpacity>

        {expandedSection === 'category' && (
          <Animated.View 
            style={[
              styles.sectionContent,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            <View style={styles.categoryContainer}>
              {analytics.categoryUsage.map(renderCategoryItem)}
            </View>
          </Animated.View>
        )}

        {/* Room Analysis */}
        <TouchableOpacity 
          activeOpacity={0.7}
          onPress={() => toggleSection('room')}
          style={styles.sectionHeaderButton}
        >
          <Animated.View 
            style={[
              styles.section,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            <View style={styles.sectionHeader}>
              <View>
                <Text style={styles.sectionTitle}>🏠 Room Analysis</Text>
                <Text style={styles.sectionSubtitle}>Energy usage by area</Text>
              </View>
              <Text style={styles.expandIcon}>{expandedSection === 'room' ? '▼' : '▶'}</Text>
            </View>
          </Animated.View>
        </TouchableOpacity>

        {expandedSection === 'room' && (
          <Animated.View 
            style={[
              styles.sectionContent,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            <View style={styles.roomGrid}>
              {analytics.roomUsage.map((roomData, index) => (
                <TouchableOpacity 
                  key={roomData[0]} 
                  style={styles.roomCard} 
                  activeOpacity={0.7}
                  onPress={() => handleRoomPress(roomData)}
                >
                  <View style={styles.roomHeader}>
                    <Text style={styles.roomIcon}>🏠</Text>
                    <Text style={styles.roomDeviceCount}>{roomData[1].count}</Text>
                  </View>
                  <Text style={styles.roomName}>{roomData[0]}</Text>
                  <Text style={styles.roomUsage}>{roomData[1].usage}W</Text>
                  <View style={styles.roomProgress}>
                    <View 
                      style={[
                        styles.roomProgressFill,
                        { width: `${(roomData[1].usage / Math.max(stats.totalUsage, 1)) * 100}%` }
                      ]} 
                    />
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </Animated.View>
        )}
      </ScrollView>

      {/* Detail Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{modalContent?.title}</Text>
              <TouchableOpacity 
                style={styles.modalCloseButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.modalCloseText}>✕</Text>
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.modalContent}>
              {renderModalContent()}
            </ScrollView>
            <TouchableOpacity 
              style={styles.modalActionButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.modalActionText}>Got it</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}