import React, { useState, useCallback, useMemo } from "react";
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  Alert, 
  ScrollView,
  SafeAreaView,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
  Image,
  ActivityIndicator,
} from "react-native";
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../Context/AuthContext';

// Validation utility functions
const validationRules = {
  email: (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim()) return "Email is required";
    if (!emailRegex.test(email)) return "Please enter a valid email address";
    return null;
  },
  
  phone: (phone) => {
    // More flexible phone validation - accepts international formats
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    if (!phone.trim()) return "Phone number is required";
    const cleanPhone = phone.replace(/[\s\-\(\)\.]/g, ''); // Remove spaces, dashes, parentheses, dots
    if (cleanPhone.length < 7) return "Phone number is too short";
    if (cleanPhone.length > 17) return "Phone number is too long";
    if (!phoneRegex.test(cleanPhone)) return "Please enter a valid phone number";
    return null;
  },
  
  password: (password) => {
    if (!password) return "Password is required";
    if (password.length < 8) return "Password must be at least 8 characters";
    if (!/(?=.*[a-z])/.test(password)) return "Password must contain at least one lowercase letter";
    if (!/(?=.*[A-Z])/.test(password)) return "Password must contain at least one uppercase letter";
    if (!/(?=.*\d)/.test(password)) return "Password must contain at least one number";
    if (!/(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?])/.test(password)) return "Password must contain at least one special character";
    if (/(.)\1{2,}/.test(password)) return "Password cannot contain 3 or more consecutive identical characters";
    if (/^[a-zA-Z]+\d+!*$/.test(password) || /^[a-zA-Z]+!\d+$/.test(password)) return "Password is too predictable. Try a more complex combination";
    return null;
  },
  
  confirmPassword: (password, confirmPassword) => {
    if (!confirmPassword) return "Please confirm your password";
    if (password !== confirmPassword) return "Passwords do not match";
    return null;
  },
  
  name: (name, fieldName) => {
    if (!name.trim()) return `${fieldName} is required`;
    if (name.trim().length < 2) return `${fieldName} must be at least 2 characters`;
    if (!/^[a-zA-Z\s]+$/.test(name)) return `${fieldName} should only contain letters`;
    return null;
  },
  
  address: (address) => {
    if (!address.trim()) return "Address is required";
    if (address.trim().length < 5) return "Please enter a complete address";
    return null;
  }
};

const InputField = React.memo(({ 
  label, 
  placeholder, 
  value, 
  onChangeText, 
  secureTextEntry = false, 
  keyboardType = "default", 
  isLoading,
  error,
  onBlur,
  showError = true
}) => (
  <View style={styles.inputGroup}>
    <Text style={styles.label}>{label}</Text>
    <TextInput
      style={[styles.input, error && styles.inputError]}
      placeholder={placeholder}
      placeholderTextColor="#6b7280"
      value={value}
      onChangeText={onChangeText}
      onBlur={onBlur}
      secureTextEntry={secureTextEntry}
      keyboardType={keyboardType}
      autoCapitalize={secureTextEntry ? "none" : "words"}
      autoCorrect={false}
      editable={!isLoading}
    />
    {error && showError && (
      <Text style={styles.errorText}>{error}</Text>
    )}
  </View>
));

export default function SignupScreen() {
  const navigation = useNavigation();
  const { signUp } = useAuth();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    emergencyName: "",
    emergencyPhone: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const updateForm = useCallback((field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  }, [errors]);

  const validateField = useCallback((field, value) => {
    let error = null;
    
    switch (field) {
      case 'firstName':
        error = validationRules.name(value, 'First name');
        break;
      case 'lastName':
        error = validationRules.name(value, 'Last name');
        break;
      case 'email':
        error = validationRules.email(value);
        break;
      case 'phone':
        error = validationRules.phone(value);
        break;
      case 'address':
        error = validationRules.address(value);
        break;
      case 'emergencyName':
        error = validationRules.name(value, 'Emergency contact name');
        break;
      case 'emergencyPhone':
        error = validationRules.phone(value);
        break;
      case 'password':
        error = validationRules.password(value);
        break;
      case 'confirmPassword':
        error = validationRules.confirmPassword(formData.password, value);
        break;
    }
    
    setErrors(prev => ({ ...prev, [field]: error }));
    return error === null;
  }, [formData.password]);

  const handleFieldBlur = useCallback((field) => {
    setTouched(prev => ({ ...prev, [field]: true }));
    validateField(field, formData[field]);
  }, [formData, validateField]);

  const validateAllFields = useCallback(() => {
    const fields = Object.keys(formData);
    let isValid = true;
    const newErrors = {};
    
    fields.forEach(field => {
      const fieldIsValid = validateField(field, formData[field]);
      if (!fieldIsValid) {
        isValid = false;
        newErrors[field] = errors[field];
      }
    });
    
    setErrors(prev => ({ ...prev, ...newErrors }));
    setTouched(fields.reduce((acc, field) => ({ ...acc, [field]: true }), {}));
    
    return isValid;
  }, [formData, validateField, errors]);

  // Check if form is valid for submit button state
  const isFormValid = useMemo(() => {
    return Object.values(formData).every(value => value.trim() !== '') &&
           Object.values(errors).every(error => error === null);
  }, [formData, errors]);

  const handleSignup = useCallback(async () => {
    if (!validateAllFields()) {
      Alert.alert("Validation Error", "Please fix all errors before submitting");
      return;
    }
    
    setIsLoading(true);
    
    const additionalData = {
      first_name: formData.firstName.trim(),
      last_name: formData.lastName.trim(),
      phone: formData.phone.replace(/[\s\-\(\)\.]/g, ''), // Clean phone number
      address: formData.address.trim(),
      emergency_contact: formData.emergencyName.trim(),
      emergency_phone: formData.emergencyPhone.replace(/[\s\-\(\)\.]/g, ''), // Clean emergency phone
    };

    const { data, error } = await signUp(
      formData.email.trim().toLowerCase(), 
      formData.password, 
      additionalData
    );
    
    setIsLoading(false);
    
    if (error) {
      Alert.alert("Registration Failed", error.message);
    } else {
      Alert.alert(
        "Account Created!", 
        "Please check your email to verify your account before signing in.",
        [{ text: "OK", onPress: () => navigation.navigate('Login') }]
      );
    }
  }, [formData, validateAllFields, signUp, navigation]);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0b" />
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.content}
      >
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.logoContainer}>
              <Image 
                source={require('../assets/logo.png')} 
                style={styles.logo} 
                resizeMode="contain"
              />
            </View>
            <Text style={styles.title}>Create Account</Text>
            <Text style={styles.subtitle}>Join Home IQ today</Text>
          </View>

          {/* Personal Info */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Personal Information</Text>
            <View style={styles.row}>
              <View style={styles.half}>
                <InputField
                  label="First Name"
                  placeholder="John"
                  value={formData.firstName}
                  onChangeText={(value) => updateForm('firstName', value)}
                  onBlur={() => handleFieldBlur('firstName')}
                  error={touched.firstName ? errors.firstName : null}
                  isLoading={isLoading}
                />
              </View>
              <View style={styles.half}>
                <InputField
                  label="Last Name"
                  placeholder="Doe"
                  value={formData.lastName}
                  onChangeText={(value) => updateForm('lastName', value)}
                  onBlur={() => handleFieldBlur('lastName')}
                  error={touched.lastName ? errors.lastName : null}
                  isLoading={isLoading}
                />
              </View>
            </View>

            <InputField
              label="Email"
              placeholder="john@example.com"
              value={formData.email}
              onChangeText={(value) => updateForm('email', value)}
              onBlur={() => handleFieldBlur('email')}
              keyboardType="email-address"
              error={touched.email ? errors.email : null}
              isLoading={isLoading}
            />

            <InputField
              label="Phone"
              placeholder="e.g. +1 123 456 7890 or 0123456789"
              value={formData.phone}
              onChangeText={(value) => updateForm('phone', value)}
              onBlur={() => handleFieldBlur('phone')}
              keyboardType="phone-pad"
              error={touched.phone ? errors.phone : null}
              isLoading={isLoading}
            />

            <InputField
              label="Address"
              placeholder="123 Main Street, City, Province"
              value={formData.address}
              onChangeText={(value) => updateForm('address', value)}
              onBlur={() => handleFieldBlur('address')}
              error={touched.address ? errors.address : null}
              isLoading={isLoading}
            />
          </View>

          {/* Emergency Contact */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Emergency Contact</Text>
            
            <InputField
              label="Contact Name"
              placeholder="Jane Doe"
              value={formData.emergencyName}
              onChangeText={(value) => updateForm('emergencyName', value)}
              onBlur={() => handleFieldBlur('emergencyName')}
              error={touched.emergencyName ? errors.emergencyName : null}
              isLoading={isLoading}
            />

            <InputField
              label="Contact Phone"
              placeholder="e.g. +1 123 456 7890 or 0123456789"
              value={formData.emergencyPhone}
              onChangeText={(value) => updateForm('emergencyPhone', value)}
              onBlur={() => handleFieldBlur('emergencyPhone')}
              keyboardType="phone-pad"
              error={touched.emergencyPhone ? errors.emergencyPhone : null}
              isLoading={isLoading}
            />
          </View>

          {/* Password */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Security</Text>
            
            <InputField
              label="Password"
              placeholder="Minimum 8 characters with special chars"
              value={formData.password}
              onChangeText={(value) => updateForm('password', value)}
              onBlur={() => handleFieldBlur('password')}
              secureTextEntry
              error={touched.password ? errors.password : null}
              isLoading={isLoading}
            />

            <InputField
              label="Confirm Password"
              placeholder="Re-enter password"
              value={formData.confirmPassword}
              onChangeText={(value) => updateForm('confirmPassword', value)}
              onBlur={() => handleFieldBlur('confirmPassword')}
              secureTextEntry
              error={touched.confirmPassword ? errors.confirmPassword : null}
              isLoading={isLoading}
            />

            {/* Password Requirements */}
            {formData.password && (
              <View style={styles.passwordRequirements}>
                <Text style={styles.requirementsTitle}>Password must contain:</Text>
                <Text style={[styles.requirement, 
                  formData.password.length >= 8 && styles.requirementMet]}>
                  • At least 8 characters
                </Text>
                <Text style={[styles.requirement, 
                  /(?=.*[a-z])/.test(formData.password) && styles.requirementMet]}>
                  • One lowercase letter
                </Text>
                <Text style={[styles.requirement, 
                  /(?=.*[A-Z])/.test(formData.password) && styles.requirementMet]}>
                  • One uppercase letter
                </Text>
                <Text style={[styles.requirement, 
                  /(?=.*\d)/.test(formData.password) && styles.requirementMet]}>
                  • One number
                </Text>
                <Text style={[styles.requirement, 
                  /(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?])/.test(formData.password) && styles.requirementMet]}>
                  • One special character (!@#$%^&*...)
                </Text>
                <Text style={[styles.requirement, 
                  !/(.)\1{2,}/.test(formData.password) && styles.requirementMet]}>
                  • No 3+ consecutive identical characters
                </Text>
                <Text style={[styles.requirement, 
                  !(/^[a-zA-Z]+\d+!*$/.test(formData.password) || /^[a-zA-Z]+!\d+$/.test(formData.password)) && styles.requirementMet]}>
                  • Not a predictable pattern
                </Text>
              </View>
            )}
          </View>

          {/* Submit */}
          <TouchableOpacity 
            style={[
              styles.submitBtn, 
              (isLoading || !isFormValid) && styles.submitBtnDisabled
            ]} 
            onPress={handleSignup}
            disabled={isLoading || !isFormValid}
          >
            {isLoading ? (
              <ActivityIndicator color="#ffffff" />
            ) : (
              <Text style={styles.submitBtnText}>Create Account</Text>
            )}
          </TouchableOpacity>

          {/* Footer */}
          <View style={styles.footer}>
            <Text style={styles.footerText}>Already have an account? </Text>
            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')}
              disabled={isLoading}
            >
              <Text style={styles.footerLink}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0b',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  header: {
    alignItems: 'center',
    paddingTop: 20,
    marginBottom: 32,
  },
  logoContainer: {
    width: 70,
    height: 70,
    borderRadius: 18,
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  logo: {
    width: 45,
    height: 45,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#ffffff',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#a1a1aa',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 16,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  half: {
    flex: 1,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 8,
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    color: '#ffffff',
  },
  inputError: {
    borderColor: '#ef4444',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
  },
  errorText: {
    color: '#ef4444',
    fontSize: 12,
    marginTop: 4,
    marginLeft: 4,
  },
  passwordRequirements: {
    marginTop: 8,
    padding: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 8,
  },
  requirementsTitle: {
    color: '#a1a1aa',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 6,
  },
  requirement: {
    color: '#6b7280',
    fontSize: 12,
    marginBottom: 2,
  },
  requirementMet: {
    color: '#10b981',
  },
  submitBtn: {
    backgroundColor: '#10b981',
    height: 50,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  submitBtnDisabled: {
    opacity: 0.6,
  },
  submitBtnText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  footerText: {
    color: '#a1a1aa',
    fontSize: 16,
  },
  footerLink: {
    color: '#10b981',
    fontSize: 16,
    fontWeight: '700',
  },
});