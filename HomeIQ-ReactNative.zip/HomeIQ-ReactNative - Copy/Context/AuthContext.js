import React, { createContext, useContext, useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

const supabaseUrl = "https://gklsblxfbnliketzmqoo.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdrbHNibHhmYm5saWtldHptcW9vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY3NDczMTUsImV4cCI6MjA3MjMyMzMxNX0.Y136mC8IO80QDrptedB-9eD_f-t0Tdpy9hBE0R-MhgU";

// Create Supabase client with AsyncStorage
const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Create Auth Context
const AuthContext = createContext({
  user: null,
  userProfile: null,
  session: null,
  loading: true,
  profileLoading: false,
  signUp: async () => {},
  signIn: async () => {},
  signOut: async () => {},
  updateProfile: async () => {},
  resetPassword: async () => {},
});

// Auth Provider Component
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [profileLoading, setProfileLoading] = useState(false);
  const [hasActivelySignedIn, setHasActivelySignedIn] = useState(false);

  // Get user profile from your profiles table
  const getUserProfile = async (userId) => {
    try {
      setProfileLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Error fetching user profile:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in getUserProfile:', error);
      return null;
    } finally {
      setProfileLoading(false);
    }
  };

  // Create or update user profile in your profiles table
  const upsertUserProfile = async (userId, profileData) => {
    try {
      setProfileLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .upsert({
          id: userId,
          ...profileData,
          updated_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) {
        console.error('Error upserting user profile:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in upsertUserProfile:', error);
      return null;
    } finally {
      setProfileLoading(false);
    }
  };

  // Sign up function
  const signUp = async (email, password, additionalData = {}) => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) {
        throw error;
      }

      // If user is created, create profile in profiles table
      if (data.user) {
        const profileData = {
          email: data.user.email,
          first_name: additionalData.first_name || null,
          last_name: additionalData.last_name || null,
          phone: additionalData.phone || null,
          address: additionalData.address || null,
          emergency_contact: additionalData.emergency_contact || null,
          emergency_phone: additionalData.emergency_phone || null,
          group_chat: additionalData.group_chat || null,
          username: additionalData.username || null,
        };

        await upsertUserProfile(data.user.id, profileData);
      }

      return { data, error: null };
    } catch (error) {
      console.error('Sign up error:', error);
      return { data: null, error };
    } finally {
      setLoading(false);
    }
  };

  // Sign in function - now fetches profile data
  const signIn = async (email, password) => {
    try {
      setLoading(true);
      setHasActivelySignedIn(true);
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        throw error;
      }

      // Fetch user profile after successful sign in
      if (data.user) {
        const profile = await getUserProfile(data.user.id);
        setUserProfile(profile);
      }

      return { data, error: null };
    } catch (error) {
      console.error('Sign in error:', error);
      setHasActivelySignedIn(false);
      return { data: null, error };
    } finally {
      setLoading(false);
    }
  };

  // Sign out function
  const signOut = async () => {
    try {
      setLoading(true);
      
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        throw error;
      }

      setUser(null);
      setUserProfile(null);
      setSession(null);
      setHasActivelySignedIn(false);
      
      return { error: null };
    } catch (error) {
      console.error('Sign out error:', error);
      return { error };
    } finally {
      setLoading(false);
    }
  };

  // Update user profile
  const updateProfile = async (updates) => {
    try {
      if (!user) {
        throw new Error('No user logged in');
      }

      const updatedProfile = await upsertUserProfile(user.id, updates);
      
      if (updatedProfile) {
        setUserProfile(updatedProfile);
      }

      return { data: updatedProfile, error: null };
    } catch (error) {
      console.error('Update profile error:', error);
      return { data: null, error };
    }
  };

  // Reset password
  const resetPassword = async (email) => {
    try {
      const { data, error } = await supabase.auth.resetPasswordForEmail(email);
      
      if (error) {
        throw error;
      }

      return { data, error: null };
    } catch (error) {
      console.error('Reset password error:', error);
      return { data: null, error };
    }
  };

  // Listen for auth state changes
  useEffect(() => {
    let mounted = true;

    // Get initial session without fetching profile
    const getInitialSession = async () => {
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (mounted) {
        if (session?.user) {
          setUser(session.user);
          setSession(session);
          // Don't fetch profile here - only set user and session
        }
        setLoading(false);
      }
    };

    getInitialSession();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (mounted) {
          console.log('Auth state changed:', event);
          
          if (session?.user) {
            setUser(session.user);
            setSession(session);
            
            // Only fetch profile if user has actively signed in
            // This prevents automatic profile fetching on app startup
            if (hasActivelySignedIn) {
              const profile = await getUserProfile(session.user.id);
              
              // If profile doesn't exist, create it
              if (!profile) {
                const newProfile = await upsertUserProfile(session.user.id, {
                  email: session.user.email,
                });
                setUserProfile(newProfile);
              } else {
                setUserProfile(profile);
              }
            }
          } else {
            setUser(null);
            setSession(null);
            setUserProfile(null);
            setHasActivelySignedIn(false);
          }
          
          setLoading(false);
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [hasActivelySignedIn]);

  // Context value
  const value = {
    user,
    userProfile,
    session,
    loading,
    profileLoading,
    signUp,
    signIn,
    signOut,
    updateProfile,
    resetPassword,
    supabase, // Export supabase client for direct use if needed
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// Hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
};

export default AuthContext;