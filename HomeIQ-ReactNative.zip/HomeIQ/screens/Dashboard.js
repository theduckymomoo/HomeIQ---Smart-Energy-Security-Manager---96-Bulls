import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  ScrollView,
  FlatList,
  RefreshControl,
  Alert,
  ActivityIndicator,
  Switch,
  Image,
  Dimensions,
  Modal,
  TextInput,
} from 'react-native';
import { useAuth } from '../Context/AuthContext';

const { width } = Dimensions.get('window');
const cardWidth = (width - 60) / 2;

export default function Dashboard() {
  const { user, userProfile, signOut, supabase } = useAuth();
  const [appliances, setAppliances] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newAppliance, setNewAppliance] = useState({
    name: '',
    type: '',
    room: '',
    normal_usage: '',
  });
  const [stats, setStats] = useState({
    totalUsage: 0,
    monthlyCost: 0,
    activeDevices: 0,
    efficiency: 85,
  });

  const getDisplayName = () => {
    if (userProfile?.first_name) {
      return userProfile.first_name;
    }
    return user?.email?.split('@')[0] || 'User';
  };

  const getApplianceIcon = (type) => {
    const iconMap = {
      refrigerator: '❄️',
      tv: '📺',
      washing_machine: '🧺',
      air_conditioner: '💨',
      heater: '🔥',
      light: '💡',
      microwave: '🔥',
      dishwasher: '🍽️',
      computer: '💻',
      fan: '💨',
    };
    return iconMap[type.toLowerCase()] || '⚡';
  };

  const getEnergyLevel = (usage) => {
    if (usage <= 50) return { label: 'Excellent', color: '#10b981' };
    if (usage <= 100) return { label: 'Good', color: '#10b981' };
    if (usage <= 200) return { label: 'Normal', color: '#f59e0b' };
    if (usage <= 300) return { label: 'Warning', color: '#f97316' };
    return { label: 'High', color: '#ef4444' };
  };

  const fetchAppliances = useCallback(async () => {
    if (!user?.id) return;

    try {
      const { data, error } = await supabase
        .from('appliances')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching appliances:', error);
        Alert.alert('Error', 'Failed to load appliances');
        return;
      }

      setAppliances(data || []);
      calculateStats(data || []);
    } catch (error) {
      console.error('Error in fetchAppliances:', error);
      Alert.alert('Error', 'Failed to load appliances');
    }
  }, [user?.id, supabase]);

  const calculateStats = (applianceList) => {
    const activeAppliances = applianceList.filter(app => app.status === 'on');
    const totalUsage = activeAppliances.reduce((sum, app) => sum + app.normal_usage, 0);

    const kWh = totalUsage / 1000;
    const hoursPerMonth = 24 * 30;
    const monthlyCost = kWh * hoursPerMonth * 2.50;

    const avgUsagePerDevice = totalUsage / Math.max(activeAppliances.length, 1);
    let efficiency = 100;
    if (avgUsagePerDevice > 300) efficiency = 60;
    else if (avgUsagePerDevice > 200) efficiency = 70;
    else if (avgUsagePerDevice > 100) efficiency = 80;
    else efficiency = 90;

    setStats({
      totalUsage: Math.round(totalUsage),
      monthlyCost: Math.round(monthlyCost),
      activeDevices: activeAppliances.length,
      efficiency,
    });
  };

  const toggleAppliance = async (applianceId, currentStatus) => {
    const newStatus = currentStatus === 'on' ? 'off' : 'on';
    
    try {
      const { error } = await supabase
        .from('appliances')
        .update({ status: newStatus })
        .eq('id', applianceId);

      if (error) {
        console.error('Error updating appliance:', error);
        Alert.alert('Error', 'Failed to update appliance status');
        return;
      }

      const updatedAppliances = appliances.map(app =>
        app.id === applianceId ? { ...app, status: newStatus } : app
      );
      setAppliances(updatedAppliances);
      calculateStats(updatedAppliances);
    } catch (error) {
      console.error('Error in toggleAppliance:', error);
      Alert.alert('Error', 'Failed to update appliance status');
    }
  };

  const addAppliance = async () => {
    if (!newAppliance.name || !newAppliance.type || !newAppliance.room || !newAppliance.normal_usage) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('appliances')
        .insert([{
          user_id: user.id,
          name: newAppliance.name,
          type: newAppliance.type,
          room: newAppliance.room,
          normal_usage: parseInt(newAppliance.normal_usage),
          status: 'off',
        }])
        .select();

      if (error) {
        console.error('Error adding appliance:', error);
        Alert.alert('Error', 'Failed to add appliance');
        return;
      }

      setAppliances([...appliances, ...data]);
      calculateStats([...appliances, ...data]);
      setNewAppliance({ name: '', type: '', room: '', normal_usage: '' });
      setShowAddModal(false);
    } catch (error) {
      console.error('Error in addAppliance:', error);
      Alert.alert('Error', 'Failed to add appliance');
    }
  };

  const handlePanic = () => {
    Alert.alert(
      'EMERGENCY ALERT',
      'This will send an emergency notification to your emergency contacts. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'SEND ALERT',
          style: 'destructive',
          onPress: () => {
            Alert.alert('Emergency Alert Sent', 'Your emergency contacts have been notified.');
          },
        },
      ]
    );
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchAppliances();
    setRefreshing(false);
  }, [fetchAppliances]);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await fetchAppliances();
      setLoading(false);
    };
    
    if (user?.id) {
      loadData();
    }
  }, [user?.id, fetchAppliances]);

  const renderDashboard = () => (
    <ScrollView
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#10b981']} />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.greeting}>Good morning</Text>
            <Text style={styles.userName}>{getDisplayName()}</Text>
          </View>
          <TouchableOpacity style={styles.panicButton} onPress={handlePanic}>
            <Text style={styles.panicText}>SOS</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Quick Stats */}
      <View style={styles.quickStats}>
        <View style={styles.statCard}>
          <Text style={styles.statIcon}>⚡</Text>
          <Text style={styles.statValue}>{stats.totalUsage}W</Text>
          <Text style={styles.statLabel}>Current Usage</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statIcon}>💰</Text>
          <Text style={styles.statValue}>R{stats.monthlyCost}</Text>
          <Text style={styles.statLabel}>Monthly Cost</Text>
        </View>
      </View>

      {/* Active Devices Section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Active Devices ({stats.activeDevices})</Text>
          <Text style={styles.efficiency}>{stats.efficiency}% efficient</Text>
        </View>
        
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.deviceScrollView}>
          {appliances.filter(app => app.status === 'on').map((item) => (
            <View key={item.id} style={styles.activeDevice}>
              <Text style={styles.deviceIcon}>{getApplianceIcon(item.type)}</Text>
              <Text style={styles.deviceName}>{item.name}</Text>
              <Text style={styles.deviceUsage}>{item.normal_usage}W</Text>
            </View>
          ))}
          {stats.activeDevices === 0 && (
            <View style={styles.noActiveDevices}>
              <Text style={styles.noActiveText}>No active devices</Text>
            </View>
          )}
        </ScrollView>
      </View>

      {/* Recent Activity */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recent Activity</Text>
        <View style={styles.activityList}>
          <View style={styles.activityItem}>
            <View style={styles.activityIcon}>
              <Text style={styles.activityIconText}>💡</Text>
            </View>
            <View style={styles.activityContent}>
              <Text style={styles.activityText}>Living Room Light turned on</Text>
              <Text style={styles.activityTime}>2 hours ago</Text>
            </View>
          </View>
          <View style={styles.activityItem}>
            <View style={styles.activityIcon}>
              <Text style={styles.activityIconText}>❄️</Text>
            </View>
            <View style={styles.activityContent}>
              <Text style={styles.activityText}>Kitchen Refrigerator optimized</Text>
              <Text style={styles.activityTime}>4 hours ago</Text>
            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  );

  const renderControls = () => (
    <ScrollView>
      <View style={styles.controlsHeader}>
        <Text style={styles.pageTitle}>Device Controls</Text>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => setShowAddModal(true)}
        >
          <Text style={styles.addButtonText}>+ Add Device</Text>
        </TouchableOpacity>
      </View>

      {appliances.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>🏠</Text>
          <Text style={styles.emptyTitle}>No Devices Added</Text>
          <Text style={styles.emptySubtitle}>Add your first smart home device to get started</Text>
        </View>
      ) : (
        <View style={styles.deviceGrid}>
          {appliances.map((item) => {
            const energyLevel = getEnergyLevel(item.normal_usage);
            const monthlyCost = Math.round((item.normal_usage / 1000) * 24 * 30 * 2.50);

            return (
              <View key={item.id} style={styles.deviceCard}>
                <View style={styles.deviceHeader}>
                  <Text style={styles.deviceCardIcon}>{getApplianceIcon(item.type)}</Text>
                  <Switch
                    value={item.status === 'on'}
                    onValueChange={() => toggleAppliance(item.id, item.status)}
                    trackColor={{ false: 'rgba(255, 255, 255, 0.2)', true: '#10b981' }}
                    thumbColor="#ffffff"
                  />
                </View>
                <Text style={styles.deviceCardName}>{item.name}</Text>
                <Text style={styles.deviceCardRoom}>{item.room}</Text>
                <View style={styles.deviceCardStats}>
                  <Text style={styles.deviceCardUsage}>{item.normal_usage}W</Text>
                  <Text style={styles.deviceCardCost}>R{monthlyCost}/mo</Text>
                </View>
                <View style={[styles.deviceCardBadge, { backgroundColor: energyLevel.color }]}>
                  <Text style={styles.deviceCardBadgeText}>{energyLevel.label}</Text>
                </View>
              </View>
            );
          })}
        </View>
      )}
    </ScrollView>
  );

  const renderAnalysis = () => (
    <ScrollView>
      <View style={styles.analysisHeader}>
        <Text style={styles.pageTitle}>Energy Analysis</Text>
      </View>
      
      {/* Usage Breakdown */}
      <View style={styles.analysisSection}>
        <Text style={styles.analysisTitle}>Usage Breakdown</Text>
        <View style={styles.usageChart}>
          <View style={styles.chartBar}>
            <View style={[styles.chartFill, { height: '70%', backgroundColor: '#10b981' }]} />
            <Text style={styles.chartLabel}>Refrigerator</Text>
          </View>
          <View style={styles.chartBar}>
            <View style={[styles.chartFill, { height: '45%', backgroundColor: '#f59e0b' }]} />
            <Text style={styles.chartLabel}>TV</Text>
          </View>
          <View style={styles.chartBar}>
            <View style={[styles.chartFill, { height: '30%', backgroundColor: '#ef4444' }]} />
            <Text style={styles.chartLabel}>Lights</Text>
          </View>
          <View style={styles.chartBar}>
            <View style={[styles.chartFill, { height: '60%', backgroundColor: '#8b5cf6' }]} />
            <Text style={styles.chartLabel}>AC</Text>
          </View>
        </View>
      </View>

      {/* Energy Efficiency Tips */}
      <View style={styles.analysisSection}>
        <Text style={styles.analysisTitle}>Efficiency Tips</Text>
        <View style={styles.tipsList}>
          <View style={styles.tip}>
            <Text style={styles.tipIcon}>💡</Text>
            <View style={styles.tipContent}>
              <Text style={styles.tipTitle}>Optimize Lighting</Text>
              <Text style={styles.tipDescription}>Switch to LED bulbs to reduce energy consumption by up to 75%</Text>
            </View>
          </View>
          <View style={styles.tip}>
            <Text style={styles.tipIcon}>❄️</Text>
            <View style={styles.tipContent}>
              <Text style={styles.tipTitle}>AC Temperature</Text>
              <Text style={styles.tipDescription}>Set your AC to 24°C to balance comfort and efficiency</Text>
            </View>
          </View>
          <View style={styles.tip}>
            <Text style={styles.tipIcon}>🔌</Text>
            <View style={styles.tipContent}>
              <Text style={styles.tipTitle}>Unplug Devices</Text>
              <Text style={styles.tipDescription}>Unplug electronics when not in use to eliminate phantom loads</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Monthly Comparison */}
      <View style={styles.analysisSection}>
        <Text style={styles.analysisTitle}>Monthly Comparison</Text>
        <View style={styles.monthlyStats}>
          <View style={styles.monthCard}>
            <Text style={styles.monthLabel}>This Month</Text>
            <Text style={styles.monthValue}>R{stats.monthlyCost}</Text>
            <Text style={[styles.monthChange, styles.monthChangeIncrease]}>+12%</Text>
          </View>
          <View style={styles.monthCard}>
            <Text style={styles.monthLabel}>Last Month</Text>
            <Text style={styles.monthValue}>R{Math.round(stats.monthlyCost * 0.88)}</Text>
            <Text style={[styles.monthChange, styles.monthChangeDecrease]}>-5%</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );

  const renderAddModal = () => (
    <Modal
      visible={showAddModal}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={() => setShowAddModal(false)}
    >
      <SafeAreaView style={styles.modalContainer}>
        <View style={styles.modalHeader}>
          <TouchableOpacity onPress={() => setShowAddModal(false)}>
            <Text style={styles.modalCancel}>Cancel</Text>
          </TouchableOpacity>
          <Text style={styles.modalTitle}>Add Device</Text>
          <TouchableOpacity onPress={addAppliance}>
            <Text style={styles.modalSave}>Save</Text>
          </TouchableOpacity>
        </View>
        
        <ScrollView style={styles.modalContent}>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Device Name</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., Living Room TV"
              placeholderTextColor="#6b7280"
              value={newAppliance.name}
              onChangeText={(text) => setNewAppliance({...newAppliance, name: text})}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Device Type</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., tv, refrigerator, light"
              placeholderTextColor="#6b7280"
              value={newAppliance.type}
              onChangeText={(text) => setNewAppliance({...newAppliance, type: text})}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Room</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., Living Room, Kitchen"
              placeholderTextColor="#6b7280"
              value={newAppliance.room}
              onChangeText={(text) => setNewAppliance({...newAppliance, room: text})}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Power Usage (Watts)</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., 100"
              placeholderTextColor="#6b7280"
              keyboardType="numeric"
              value={newAppliance.normal_usage}
              onChangeText={(text) => setNewAppliance({...newAppliance, normal_usage: text})}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#10b981" />
          <Text style={styles.loadingText}>Loading Dashboard...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0b" />
      
      {/* Content */}
      <View style={styles.content}>
        {activeTab === 'dashboard' && renderDashboard()}
        {activeTab === 'controls' && renderControls()}
        {activeTab === 'analysis' && renderAnalysis()}
      </View>

      {/* Bottom Navigation */}
      <View style={styles.bottomNav}>
        <TouchableOpacity 
          style={[styles.navItem, activeTab === 'dashboard' && styles.navItemActive]}
          onPress={() => setActiveTab('dashboard')}
        >
          <Text style={[styles.navIcon, activeTab === 'dashboard' && styles.navIconActive]}>🏠</Text>
          <Text style={[styles.navLabel, activeTab === 'dashboard' && styles.navLabelActive]}>Home</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.navItem, activeTab === 'controls' && styles.navItemActive]}
          onPress={() => setActiveTab('controls')}
        >
          <Text style={[styles.navIcon, activeTab === 'controls' && styles.navIconActive]}>🎛️</Text>
          <Text style={[styles.navLabel, activeTab === 'controls' && styles.navLabelActive]}>Controls</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.navItem, activeTab === 'analysis' && styles.navItemActive]}
          onPress={() => setActiveTab('analysis')}
        >
          <Text style={[styles.navIcon, activeTab === 'analysis' && styles.navIconActive]}>📊</Text>
          <Text style={[styles.navLabel, activeTab === 'analysis' && styles.navLabelActive]}>Analysis</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.navItem}
          onPress={signOut}
        >
          <Text style={styles.navIcon}>🚪</Text>
          <Text style={styles.navLabel}>Exit</Text>
        </TouchableOpacity>
      </View>

      {renderAddModal()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0b',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#a1a1aa',
  },
  content: {
    flex: 1,
  },
  
  // Header
  header: {
    padding: 24,
    paddingTop: 12,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  greeting: {
    fontSize: 16,
    color: '#a1a1aa',
    marginBottom: 4,
  },
  userName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#ffffff',
  },
  panicButton: {
    backgroundColor: '#ef4444',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  panicText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 12,
  },

  // Quick Stats
  quickStats: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    gap: 16,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  statIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  statValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#a1a1aa',
  },

  // Sections
  section: {
    paddingHorizontal: 24,
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#ffffff',
  },
  efficiency: {
    fontSize: 14,
    color: '#10b981',
    fontWeight: '500',
  },

  // Active Devices
  deviceScrollView: {
    marginTop: 8,
  },
  activeDevice: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginRight: 12,
    alignItems: 'center',
    minWidth: 80,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  deviceIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  deviceName: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '500',
    textAlign: 'center',
    marginBottom: 4,
  },
  deviceUsage: {
    fontSize: 10,
    color: '#a1a1aa',
  },
  noActiveDevices: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 20,
  },
  noActiveText: {
    color: '#6b7280',
    fontSize: 14,
  },

  // Activity
  activityList: {
    gap: 12,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  activityIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  activityIconText: {
    fontSize: 20,
  },
  activityContent: {
    flex: 1,
  },
  activityText: {
    fontSize: 14,
    color: '#ffffff',
    fontWeight: '500',
    marginBottom: 2,
  },
  activityTime: {
    fontSize: 12,
    color: '#a1a1aa',
  },

  // Controls Page
  controlsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 24,
    paddingBottom: 16,
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#ffffff',
    // Removed duplicate padding from here to fix layout
  },
  addButton: {
    backgroundColor: '#10b981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonText: {
    color: '#ffffff',
    fontWeight: '600',
    fontSize: 14,
  },
  deviceGrid: {
    paddingHorizontal: 24,
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    justifyContent: 'space-between', // Added to properly space cards
  },
  deviceCard: {
    width: cardWidth,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    marginBottom: 16, // Added to prevent cards from touching
  },
  deviceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  deviceCardIcon: {
    fontSize: 28,
  },
  deviceCardName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 4,
  },
  deviceCardRoom: {
    fontSize: 12,
    color: '#a1a1aa',
    marginBottom: 12,
  },
  deviceCardStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  deviceCardUsage: {
    fontSize: 14,
    color: '#ffffff',
    fontWeight: '500',
  },
  deviceCardCost: {
    fontSize: 14,
    color: '#a1a1aa',
  },
  deviceCardBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  deviceCardBadgeText: {
    color: '#ffffff',
    fontSize: 10,
    fontWeight: '600',
  },

  // Analysis Page
  analysisHeader: {
    padding: 24,
    paddingBottom: 16,
  },
  analysisSection: {
    paddingHorizontal: 24,
    marginBottom: 32,
  },
  analysisTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 16,
  },
  usageChart: {
    flexDirection: 'row',
    height: 120,
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  chartBar: {
    alignItems: 'center',
    flex: 1,
    height: '100%',
    justifyContent: 'flex-end',
  },
  chartFill: {
    width: 20,
    borderRadius: 10,
    marginBottom: 8,
  },
  chartLabel: {
    fontSize: 10,
    color: '#a1a1aa',
    textAlign: 'center',
  },
  tipsList: {
    gap: 12,
  },
  tip: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    alignItems: 'center',
  },
  tipIcon: {
    fontSize: 24,
    marginRight: 16,
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    padding: 8,
    borderRadius: 8,
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 4,
  },
  tipDescription: {
    fontSize: 12,
    color: '#a1a1aa',
  },
  monthlyStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 16,
  },
  monthCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  monthLabel: {
    fontSize: 12,
    color: '#a1a1aa',
    marginBottom: 4,
  },
  monthValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 4,
  },
  monthChange: {
    fontSize: 12,
    fontWeight: '600',
  },
  monthChangeIncrease: {
    color: '#ef4444',
  },
  monthChangeDecrease: {
    color: '#10b981',
  },

  // Modal
  modalContainer: {
    flex: 1,
    backgroundColor: '#18181b',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  modalCancel: {
    fontSize: 16,
    color: '#ef4444',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#ffffff',
  },
  modalSave: {
    fontSize: 16,
    fontWeight: '600',
    color: '#10b981',
  },
  modalContent: {
    padding: 24,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#a1a1aa',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#ffffff',
  },

  // Bottom Nav
  bottomNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#18181b',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 12,
  },
  navItem: {
    alignItems: 'center',
    flex: 1,
  },
  navItemActive: {
    // Add active styling here if needed
  },
  navIcon: {
    fontSize: 24,
    color: '#a1a1aa',
    marginBottom: 4,
  },
  navIconActive: {
    color: '#10b981',
  },
  navLabel: {
    fontSize: 12,
    color: '#a1a1aa',
  },
  navLabelActive: {
    color: '#10b981',
    fontWeight: '600',
  },
});