import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Alert, 
  Image, 
  StatusBar,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

export default function LandingScreen() {
  const navigation = useNavigation();
  const [panicPressed, setPanicPressed] = useState(false);
  const [firePressed, setFirePressed] = useState(false);

  const handlePanic = () => {
    if (panicPressed) return;
    setPanicPressed(true);
    setTimeout(() => {
      Alert.alert('Emergency Alert Sent', 'Your trusted contacts have been notified');
      setPanicPressed(false);
    }, 2000);
  };

  const handleFire = () => {
    if (firePressed) return;
    setFirePressed(true);
    setTimeout(() => {
      Alert.alert('Fire Alert Sent', 'Emergency services have been contacted');
      setFirePressed(false);
    }, 2000);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0b" />
      
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.logoContainer}>
          <Image 
            source={require('../assets/logo.png')} 
            style={styles.logo} 
            resizeMode="contain"
          />
        </View>
        <Text style={styles.appName}>Home IQ</Text>
        <Text style={styles.tagline}>Smart Living</Text>
      </View>

      {/* Emergency Controls */}
      <View style={styles.emergencySection}>
        <Text style={styles.emergencyTitle}>Emergency Response</Text>
        <View style={styles.emergencyButtons}>
          <TouchableOpacity
            onPress={handlePanic}
            disabled={panicPressed}
            style={[styles.emergencyBtn, styles.panicBtn, panicPressed && styles.loading]}
            activeOpacity={0.7}
          >
            <Text style={styles.emergencyText}>
              {panicPressed ? 'SENDING...' : 'PANIC'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={handleFire}
            disabled={firePressed}
            style={[styles.emergencyBtn, styles.fireBtn, firePressed && styles.loading]}
            activeOpacity={0.7}
          >
            <Text style={styles.emergencyText}>
              {firePressed ? 'SENDING...' : 'FIRE'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Main Content */}
      <View style={styles.main}>
        <Text style={styles.heroTitle}>
          Control Your Home{'\n'}From Anywhere
        </Text>
        <Text style={styles.heroSubtitle}>
          Secure your home with intelligent monitoring and instant emergency response
        </Text>
      </View>

      {/* Action Buttons */}
      <View style={styles.actions}>
        <TouchableOpacity
          onPress={() => navigation.navigate('Login')}
          style={styles.primaryBtn}
        >
          <Text style={styles.primaryBtnText}>Sign In</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => navigation.navigate('Signup')}
          style={styles.secondaryBtn}
        >
          <Text style={styles.secondaryBtnText}>Create Account</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0b',
    paddingHorizontal: 24,
  },
  header: {
    alignItems: 'center',
    paddingTop: 40,
    paddingBottom: 32,
  },
  logoContainer: {
    width: 60,
    height: 60,
    borderRadius: 16,
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  logo: {
    width: 36,
    height: 36,
  },
  appName: {
    fontSize: 28,
    fontWeight: '800',
    color: '#ffffff',
    marginBottom: 4,
  },
  tagline: {
    fontSize: 14,
    color: '#10b981',
    fontWeight: '600',
  },
  emergencySection: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 40,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  emergencyTitle: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 16,
  },
  emergencyButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  emergencyBtn: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  panicBtn: {
    backgroundColor: '#ef4444',
  },
  fireBtn: {
    backgroundColor: '#f59e0b',
  },
  loading: {
    opacity: 0.7,
  },
  emergencyText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  main: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
  },
  heroTitle: {
    fontSize: 36,
    fontWeight: '900',
    color: '#ffffff',
    textAlign: 'center',
    lineHeight: 42,
    marginBottom: 16,
  },
  heroSubtitle: {
    fontSize: 16,
    color: '#a1a1aa',
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: 20,
  },
  actions: {
    paddingBottom: 40,
    gap: 12,
  },
  primaryBtn: {
    backgroundColor: '#10b981',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  primaryBtnText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  secondaryBtn: {
    borderWidth: 1,
    borderColor: '#10b981',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  secondaryBtnText: {
    color: '#10b981',
    fontSize: 16,
    fontWeight: '700',
  },
});