import React, { useState, useCallback } from "react";
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  Alert, 
  ScrollView,
  SafeAreaView,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
  Image,
  ActivityIndicator,
} from "react-native";
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../Context/AuthContext';

const InputField = React.memo(({ label, placeholder, value, onChangeText, secureTextEntry = false, keyboardType = "default", isLoading }) => (
  <View style={styles.inputGroup}>
    <Text style={styles.label}>{label}</Text>
    <TextInput
      style={styles.input}
      placeholder={placeholder}
      placeholderTextColor="#6b7280"
      value={value}
      onChangeText={onChangeText}
      secureTextEntry={secureTextEntry}
      keyboardType={keyboardType}
      autoCapitalize={secureTextEntry ? "none" : "words"}
      autoCorrect={false}
      editable={!isLoading}
    />
  </View>
));

export default function SignupScreen() {
  const navigation = useNavigation();
  const { signUp } = useAuth();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    emergencyName: "",
    emergencyPhone: "",
    password: "",
    confirmPassword: "",
  });
  const [isLoading, setIsLoading] = useState(false);

  const updateForm = useCallback((field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  }, []);

  const validateForm = useCallback(() => {
    const required = ['firstName', 'lastName', 'email', 'phone', 'address', 'emergencyName', 'emergencyPhone', 'password', 'confirmPassword'];
    
    for (let field of required) {
      if (!formData[field].trim()) {
        Alert.alert("Error", "Please fill all required fields");
        return false;
      }
    }

    if (!formData.email.includes('@')) {
      Alert.alert("Error", "Please enter a valid email address");
      return false;
    }
    
    if (formData.password !== formData.confirmPassword) {
      Alert.alert("Error", "Passwords do not match");
      return false;
    }
    
    if (formData.password.length < 6) {
      Alert.alert("Error", "Password must be at least 6 characters");
      return false;
    }
    
    return true;
  }, [formData]);

  const handleSignup = useCallback(async () => {
    if (!validateForm()) return;
    
    setIsLoading(true);
    
    const additionalData = {
      first_name: formData.firstName.trim(),
      last_name: formData.lastName.trim(),
      phone: formData.phone.trim(),
      address: formData.address.trim(),
      emergency_contact: formData.emergencyName.trim(),
      emergency_phone: formData.emergencyPhone.trim(),
    };

    const { data, error } = await signUp(
      formData.email.trim().toLowerCase(), 
      formData.password, 
      additionalData
    );
    
    setIsLoading(false);
    
    if (error) {
      Alert.alert("Registration Failed", error.message);
    } else {
      Alert.alert(
        "Account Created!", 
        "Please check your email to verify your account before signing in.",
        [{ text: "OK", onPress: () => navigation.navigate('Login') }]
      );
    }
  }, [formData, validateForm, signUp, navigation]);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0b" />
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.content}
      >
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.logoContainer}>
              <Image 
                source={require('../assets/logo.png')} 
                style={styles.logo} 
                resizeMode="contain"
              />
            </View>
            <Text style={styles.title}>Create Account</Text>
            <Text style={styles.subtitle}>Join Home IQ today</Text>
          </View>

          {/* Personal Info */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Personal Information</Text>
            <View style={styles.row}>
              <View style={styles.half}>
                <InputField
                  label="First Name"
                  placeholder="John"
                  value={formData.firstName}
                  onChangeText={(value) => updateForm('firstName', value)}
                  isLoading={isLoading}
                />
              </View>
              <View style={styles.half}>
                <InputField
                  label="Last Name"
                  placeholder="Doe"
                  value={formData.lastName}
                  onChangeText={(value) => updateForm('lastName', value)}
                  isLoading={isLoading}
                />
              </View>
            </View>

            <InputField
              label="Email"
              placeholder="john@example.com"
              value={formData.email}
              onChangeText={(value) => updateForm('email', value)}
              keyboardType="email-address"
              isLoading={isLoading}
            />

            <InputField
              label="Phone"
              placeholder="+27 12 345 6789"
              value={formData.phone}
              onChangeText={(value) => updateForm('phone', value)}
              keyboardType="phone-pad"
              isLoading={isLoading}
            />

            <InputField
              label="Address"
              placeholder="123 Main Street"
              value={formData.address}
              onChangeText={(value) => updateForm('address', value)}
              isLoading={isLoading}
            />
          </View>

          {/* Emergency Contact */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Emergency Contact</Text>
            
            <InputField
              label="Contact Name"
              placeholder="Jane Doe"
              value={formData.emergencyName}
              onChangeText={(value) => updateForm('emergencyName', value)}
              isLoading={isLoading}
            />

            <InputField
              label="Contact Phone"
              placeholder="+27 11 987 6543"
              value={formData.emergencyPhone}
              onChangeText={(value) => updateForm('emergencyPhone', value)}
              keyboardType="phone-pad"
              isLoading={isLoading}
            />
          </View>

          {/* Password */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Security</Text>
            
            <InputField
              label="Password"
              placeholder="Minimum 6 characters"
              value={formData.password}
              onChangeText={(value) => updateForm('password', value)}
              secureTextEntry
              isLoading={isLoading}
            />

            <InputField
              label="Confirm Password"
              placeholder="Re-enter password"
              value={formData.confirmPassword}
              onChangeText={(value) => updateForm('confirmPassword', value)}
              secureTextEntry
              isLoading={isLoading}
            />
          </View>

          {/* Submit */}
          <TouchableOpacity 
            style={[styles.submitBtn, isLoading && styles.submitBtnDisabled]} 
            onPress={handleSignup}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="#ffffff" />
            ) : (
              <Text style={styles.submitBtnText}>Create Account</Text>
            )}
          </TouchableOpacity>

          {/* Footer */}
          <View style={styles.footer}>
            <Text style={styles.footerText}>Already have an account? </Text>
            <TouchableOpacity 
              onPress={() => navigation.navigate('Login')}
              disabled={isLoading}
            >
              <Text style={styles.footerLink}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0b',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  header: {
    alignItems: 'center',
    paddingTop: 20,
    marginBottom: 32,
  },
  logoContainer: {
    width: 70,
    height: 70,
    borderRadius: 18,
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  logo: {
    width: 45,
    height: 45,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#ffffff',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#a1a1aa',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 16,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  half: {
    flex: 1,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 8,
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    color: '#ffffff',
  },
  submitBtn: {
    backgroundColor: '#10b981',
    height: 50,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  submitBtnDisabled: {
    opacity: 0.6,
  },
  submitBtnText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  footerText: {
    color: '#a1a1aa',
    fontSize: 16,
  },
  footerLink: {
    color: '#10b981',
    fontSize: 16,
    fontWeight: '700',
  },
});